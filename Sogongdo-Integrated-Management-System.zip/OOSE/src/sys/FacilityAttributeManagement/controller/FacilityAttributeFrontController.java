package sys.FacilityAttributeManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityAttributeManagement.model.FacilityAttribute;
import sys.FacilityAttributeManagement.model.FacilityAttributeDAO;
import javax.servlet.http.HttpServlet;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import java.util.*;


public class FacilityAttributeFrontController extends HttpServlet{
	private static final long serialVersionUID = 2L;
	String charset = null;
	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		charset = config.getInitParameter("charset");
		list = new HashMap<String, Controller>();
		list.put("/facilityAttributeEnroll.facat",  new FacilityAttributeEnrollController());
		list.put("/facilityAttributeUpdate.facat",  new FacilityAttributeUpdateController());
		list.put("/facilityAttributeDelete.facat",  new FacilityAttributeDeleteController());
		list.put("/facilityAttributeList.facat" , new FacilityAttributeListController());
		
	}
	
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding(charset);
		String url = request.getRequestURI();
		String contextPath = request.getContextPath();
		String path = url.substring(contextPath.length());
		
		Controller subController = list.get(path);
		subController.execute(request, response);
	}
	
}
