package sys.FacilityAttributeManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityAttributeManagement.model.FacilityAttribute;
import sys.FacilityAttributeManagement.model.FacilityAttributeDAO;
import java.util.ArrayList;

public class FacilityAttributeService {

	private static FacilityAttributeService service = new FacilityAttributeService();
	public FacilityAttributeDAO dao = FacilityAttributeDAO.getInstance();

	private FacilityAttributeService() {
			
		}

	public static FacilityAttributeService getInstance() {
		return service;
	}

	public void facilityAttributeEnroll(FacilityAttribute facilityAttribute) {
		dao.facilityAttributeEnroll(facilityAttribute);
	}

	public void facilityAttributeUpdate(FacilityAttribute member) {
		dao.facilityAttributeUpdate(member);
	}

	public void facilityAttributeDelete(String id) {
		dao.facilityAttributeDelete(id);
	}

	public ArrayList<FacilityAttribute> facilityAttributeList(String facilityId) {
		ArrayList<FacilityAttribute> list = dao.getFacilityAttributeList(facilityId);
		return list;
	}


}
