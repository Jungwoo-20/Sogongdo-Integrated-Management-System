package sys.FacilityAttributeManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityAttributeManagement.model.FacilityAttribute;
import sys.FacilityAttributeManagement.model.FacilityAttributeDAO;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FacilityAttributeUpdateController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String facilityAttributeId = request.getParameter("facilityAttributeId");
		String facilityId = request.getParameter("facilityId");
		String facilityAttributeName = request.getParameter("facilityAttributeName");
		String facilityAttributeValue = request.getParameter("facilityAttributeValue");
		
		FacilityAttribute facilityAttribute = new FacilityAttribute();
		facilityAttribute.setFacilityAttributeId(facilityAttributeId);
		facilityAttribute.setFacilityId(facilityId);
		facilityAttribute.setFacilityAttributeName(facilityAttributeName);
		facilityAttribute.setFacilityAttributeValue(facilityAttributeValue);

		FacilityAttributeService service = FacilityAttributeService.getInstance();
		service.facilityAttributeUpdate(facilityAttribute);
		
		request.setAttribute("facilityAttributeId",facilityAttributeId);
		HttpUtil.forward(request, response, "/result/FacilityAttributeUpdateResult.jsp");
	}

}
