package sys.FacilityAttributeManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityAttributeManagement.model.FacilityAttribute;
import sys.FacilityAttributeManagement.model.FacilityAttributeDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





public class FacilityAttributeDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String facilityAttributeId = request.getParameter("facilityAttributeId");
		FacilityAttributeService service = FacilityAttributeService.getInstance();
		FacilityAttributeDAO dao = FacilityAttributeDAO.getInstance();
		FacilityAttribute facilityAttribute = dao.getFacilityAttribute(facilityAttributeId);
		service.facilityAttributeDelete(facilityAttributeId);
		request.setAttribute("facilityAttributeId",facilityAttributeId);
		HttpUtil.forward(request, response, "/FacilityAttributeListView.jsp?facilityId="+facilityAttribute.getFacilityId());
	}

}
