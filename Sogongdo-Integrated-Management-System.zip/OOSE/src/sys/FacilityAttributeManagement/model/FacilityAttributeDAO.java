package sys.FacilityAttributeManagement.model;

import java.sql.*;
import java.util.ArrayList;

import sys.Dao;



public class FacilityAttributeDAO extends Dao{
	private static FacilityAttributeDAO dao = new FacilityAttributeDAO();
	private FacilityAttributeDAO(){}	
	public static FacilityAttributeDAO getInstance() {
		return dao;
	}
	
	public void facilityAttributeEnroll(FacilityAttribute facilityAttribute) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("insert into jspmodel2.facilityattributes values(?,?,?,?)");
			pstmt.setString(1, facilityAttribute.getFacilityAttributeId());
			pstmt.setString(2, facilityAttribute.getFacilityId());
			pstmt.setString(3, facilityAttribute.getFacilityAttributeName());
			pstmt.setString(4, facilityAttribute.getFacilityAttributeValue());
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB insert ����" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public ArrayList<FacilityAttribute> getFacilityAttributeList(String facilityId) {

		ArrayList<FacilityAttribute> list = new ArrayList<FacilityAttribute>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		FacilityAttribute facilityAttribute = null;

		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from jspmodel2.facilityattributes where facilityId=?");
			pstmt.setString(1, facilityId);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				facilityAttribute = new FacilityAttribute();
				facilityAttribute.setFacilityAttributeId(rs.getString(1));
				facilityAttribute.setFacilityId(rs.getString(2));
				facilityAttribute.setFacilityAttributeName(rs.getString(3));
				facilityAttribute.setFacilityAttributeValue(rs.getString(4));
				list.add(facilityAttribute);
			}
		} catch (Exception ex) {
			System.out.println("����Ʈ ���� �߻� : " + ex);
		} finally {
			close(conn, pstmt, rs);
		}

		return list;
	}
	
	public FacilityAttribute getFacilityAttribute(String facilityAttributeId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		FacilityAttribute facilityAttribute = null;		
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from jspmodel2.facilityattributes where facilityAttributeId=?");
			pstmt.setString(1, facilityAttributeId);
			rs = pstmt.executeQuery();
			
			rs.next();
			facilityAttribute = new FacilityAttribute();
			facilityAttribute.setFacilityAttributeId(rs.getString(1));
			facilityAttribute.setFacilityId(rs.getString(2));
			facilityAttribute.setFacilityAttributeName(rs.getString(3));
			facilityAttribute.setFacilityAttributeValue(rs.getString(4));

		} catch (Exception ex) {
			System.out.println("����Ʈ ���� �߻� : " + ex);
		} finally {
			close(conn, pstmt, rs);
		}
		return facilityAttribute;
	}
	
	public void facilityAttributeDelete(String facilityAttributeId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("delete from jspmodel2.facilityattributes where facilityAttributeId=?");
			pstmt.setString(1, facilityAttributeId);
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB delete error" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public void facilityAttributeUpdate(FacilityAttribute facilityAttribute) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("Update jspmodel2.facilityattributes set facilityId=?, facilityAttributeName=?, facilityAttributeValue=? where facilityAttributeId=?");
			
			
			pstmt.setString(1, facilityAttribute.getFacilityId());
			pstmt.setString(2, facilityAttribute.getFacilityAttributeName());
			pstmt.setString(3, facilityAttribute.getFacilityAttributeValue());
			pstmt.setString(4, facilityAttribute.getFacilityAttributeId());
			
			pstmt.executeUpdate();
		}catch (Exception ex) {
			System.out.println("DB ������Ʈ ����" + ex);
		}finally {
			close(conn,pstmt);
		}
	}
	
}
