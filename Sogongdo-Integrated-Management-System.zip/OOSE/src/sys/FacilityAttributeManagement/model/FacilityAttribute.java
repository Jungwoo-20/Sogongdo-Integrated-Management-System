package sys.FacilityAttributeManagement.model;



public class FacilityAttribute {
	private String facilityAttributeId;
	private String facilityId;
	private String facilityAttributeName;
	private String facilityAttributeValue;
	
	public String getFacilityAttributeId() {
		return facilityAttributeId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public String getFacilityAttributeName() {
		return facilityAttributeName;
	}
	public String getFacilityAttributeValue() {
		return facilityAttributeValue;
	}
	public void setFacilityAttributeId(String facilityAttributeId) {
		this.facilityAttributeId = facilityAttributeId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public void setFacilityAttributeName(String facilityAttributeName) {
		this.facilityAttributeName = facilityAttributeName;
	}
	public void setFacilityAttributeValue(String facilityAttributeValue) {
		this.facilityAttributeValue = facilityAttributeValue;
	}

	
}
