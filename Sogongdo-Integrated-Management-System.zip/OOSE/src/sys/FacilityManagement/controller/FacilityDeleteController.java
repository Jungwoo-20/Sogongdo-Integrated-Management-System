package sys.FacilityManagement.controller;

import sys.Controller;
import sys.HttpUtil;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class FacilityDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String facilityId = request.getParameter("facilityId");
		FacilityService service = FacilityService.getInstance();
		service.facilityDelete(facilityId);
		request.setAttribute("facilityId",facilityId);
		HttpUtil.forward(request, response, "/FacilityListView.jsp");
	}

}
