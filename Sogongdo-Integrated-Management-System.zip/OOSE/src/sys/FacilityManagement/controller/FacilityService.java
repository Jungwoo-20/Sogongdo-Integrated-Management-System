package sys.FacilityManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityManagement.model.*;
import java.util.ArrayList;

public class FacilityService {

	private static FacilityService service = new FacilityService();
	public FacilityDAO dao = FacilityDAO.getInstance();

	private FacilityService() {
			
		}

	public static FacilityService getInstance() {
		return service;
	}

	public void facilityEnroll(Facility facility) {
		dao.facilityEnroll(facility);
	}

	public void facilityUpdate(Facility member) {
		dao.facilityUpdate(member);
	}

	public void facilityDelete(String id) {
		dao.facilityDelete(id);
	}

	public ArrayList<Facility> facilityList() {
		ArrayList<Facility> list = dao.getFacilityList();
		return list;
	}

}
