package sys.FacilityManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityManagement.model.*;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FacilityListController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String auth = (String)request.getSession().getAttribute("authority");
		if(auth !=null) {
			if(auth.equals("20") || auth.equals("30") || auth.equals("40") || auth.equals("50")) {
				HttpUtil.forward(request, response, "/FacilityListView.jsp");
			}
			else {
				HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
			}
		}else {
			HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
		}

	}

}
