package sys.FacilityManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityManagement.model.*;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FacilityEnrollController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String facilityId = request.getParameter("facilityId");
		String facilityName = request.getParameter("facilityName");
		String facilityType = request.getParameter("facilityType");
		String businessPlaceId = request.getParameter("businessPlaceId");
		String managerId = request.getParameter("managerId");
		String facilityStatus = request.getParameter("facilityStatus");
		String telNum = request.getParameter("telNum");
		

//		if(id.isEmpty() || name.isEmpty() || price.isEmpty()) {
//			request.setAttribute("error", "�ʼ� ���� ���Է�");
//			HttpUtil.forward(request, response, "/ProductEnroll.jsp");
//			return;
//		}
		

		Facility facility = new Facility();
		facility.setFacilityId(facilityId);
		facility.setFacilityName(facilityName);
		facility.setFacilityType(facilityType);
		facility.setBusinessPlaceId(businessPlaceId);
		facility.setManagerId(managerId);
		facility.setFacilityStatus(facilityStatus); 
		facility.setTelNum(Integer.parseInt(telNum));

		FacilityService service = FacilityService.getInstance();
		service.facilityEnroll(facility);
		
		request.setAttribute("facilityId",facilityId);
		HttpUtil.forward(request, response, "/result/FacilityEnrollResult.jsp");
	}

}