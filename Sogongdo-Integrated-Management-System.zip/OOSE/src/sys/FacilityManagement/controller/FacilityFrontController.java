package sys.FacilityManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.FacilityManagement.model.*;
import javax.servlet.http.HttpServlet;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import java.util.*;


public class FacilityFrontController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	String charset = null;
	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		charset = config.getInitParameter("charset");
		list = new HashMap<String, Controller>();
		list.put("/facilityEnroll.fac",  new FacilityEnrollController());
		list.put("/facilityUpdate.fac",  new FacilityUpdateController());
		list.put("/facilityDelete.fac",  new FacilityDeleteController());
		list.put("/facilityList.fac" , new FacilityListController());
		
	}
	
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		request.setCharacterEncoding(charset);
		String url = request.getRequestURI();
		String contextPath = request.getContextPath();
		String path = url.substring(contextPath.length());
		System.out.println("fac");
		Controller subController = list.get(path);
		subController.execute(request, response);
	}
	
}
