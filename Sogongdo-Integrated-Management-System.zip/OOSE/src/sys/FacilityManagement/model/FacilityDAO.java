package sys.FacilityManagement.model;



import java.sql.*;
import java.util.ArrayList;

import com.sun.net.httpserver.Authenticator.Result;

import sys.Dao;



public class FacilityDAO  extends Dao{
	private static FacilityDAO dao = new FacilityDAO();
	private FacilityDAO(){}	
	public static FacilityDAO getInstance() {
		return dao;
	}
	

	public void facilityEnroll(Facility facility) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("insert into oose.facility values(?,?,?,?,?,?,?)");
			pstmt.setString(1, facility.getFacilityId());
			pstmt.setString(2, facility.getBusinessPlaceId());
			pstmt.setString(3, facility.getFacilityName());
			pstmt.setString(4, facility.getFacilityType());
			pstmt.setString(5, facility.getFacilityStatus());
			pstmt.setString(6, facility.getManagerId());
			pstmt.setInt(7, facility.getTelNum());
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB insert ����" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public ArrayList<Facility> getFacilityList() {

		ArrayList<Facility> list = new ArrayList<Facility>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		Facility facility = null;
		int checkerror=0;

		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from oose.facility");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				facility = new Facility();
				facility.setFacilityId(rs.getString(1));
				facility.setBusinessPlaceId(rs.getString(2));
				facility.setFacilityName(rs.getString(3));
				facility.setFacilityType(rs.getString(4));
				facility.setFacilityStatus(rs.getString(5));
				facility.setManagerId(rs.getString(6));
				facility.setTelNum(rs.getInt(7));
				list.add(facility);
			}

		} catch (Exception ex) {
			System.out.println("����Ʈ ���� �߻� : " + ex + checkerror);
		} finally {
			close(conn, pstmt, rs);
		}

		return list;
	}
	
	public Facility getFacility(String facilityId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Facility facility = null;
		
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from oose.facility where facilityId=?");
			pstmt.setString(1, facilityId);
			rs = pstmt.executeQuery();

			
			rs.next();
			facility = new Facility();
			facility.setFacilityId(rs.getString(1));
			facility.setBusinessPlaceId(rs.getString(2));
			facility.setFacilityName(rs.getString(3));
			facility.setFacilityType(rs.getString(4));
			facility.setFacilityStatus(rs.getString(5));
			facility.setManagerId(rs.getString(6));
			facility.setTelNum(rs.getInt(7));

		} catch (Exception ex) {
			System.out.println("�ü� ����Ʈ ���� �߻� : " + ex);
		} finally {
			close(conn, pstmt, rs);
		}
		return facility; 
	}
	
	public void facilityDelete(String facilityId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("delete from oose.facility where facilityId=?");
			pstmt.setString(1, facilityId);
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB delete error" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public void facilityUpdate(Facility facility) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("Update oose.facility set businessPlaceId=?, facilityName=?, facilityType=?, facilityStatus=?, managerId=?, telNum=? where facilityId=?");
			
			pstmt.setString(1, facility.getBusinessPlaceId());
			pstmt.setString(2, facility.getFacilityName());
			pstmt.setString(3, facility.getFacilityType());
			pstmt.setString(4, facility.getFacilityStatus());
			pstmt.setString(5, facility.getManagerId());
			pstmt.setInt(6, facility.getTelNum());
			pstmt.setString(7, facility.getFacilityId());
			
			pstmt.executeUpdate();
		}catch (Exception ex) {
			System.out.println("DB ������Ʈ ����" + ex);
		}finally {
			close(conn,pstmt);
		}
	}
	
}
