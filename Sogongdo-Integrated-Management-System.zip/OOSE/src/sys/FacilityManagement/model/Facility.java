package sys.FacilityManagement.model;


public class Facility {
	private String facilityId;
	private String facilityName;
	private String facilityType;
	private String businessPlaceId;
	private String managerId;
	private String facilityStatus;
	private int telNum;
	
	
	
	public String getFacilityId() {
		return facilityId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public String getFacilityType() {
		return facilityType;
	}
	public String getBusinessPlaceId() {
		return businessPlaceId;
	}
	public String getManagerId() {
		return managerId;
	}
	public String getFacilityStatus() {
		return facilityStatus;
	}
	public int getTelNum() {
		return telNum;
	}
	
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}
	public void setBusinessPlaceId(String businessPlaceId) {
		this.businessPlaceId = businessPlaceId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	public void setFacilityStatus(String facilityStatus) {
		this.facilityStatus = facilityStatus;
	}
	public void setTelNum(int telNum) {
		this.telNum = telNum;
	}
	
	
}
