package sys.DiscountManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.DiscountManagement.model.*;
import java.util.ArrayList;


public class DiscountService {
	private static DiscountService service = new DiscountService();
	public DiscountDAO dao = DiscountDAO.getInstance();
	
	private DiscountService() {}
	
	public static DiscountService getInstance() {
		return service;
	}
	
	public void DiscountEnroll(Discount discount) {
		dao.DiscountEnroll(discount);
	}
	
	public void DiscountUpdate(Discount discount) {
		dao.DiscountUpdate(discount);
	}
	
	public void DiscountDelete(String discountId) {
		dao.DiscountDelete(discountId);
	}
	
	public ArrayList<Discount> discountList(){
		ArrayList<Discount> list = dao.getDiscountList();
		return list;
	}
	
	

}
