package sys.DiscountManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.DiscountManagement.model.*;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DiscountEnrollController implements Controller{

	public String getRandomDiscountId( int length ){
        char[] charaters = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9'};
        StringBuffer sb = new StringBuffer();
        Random rn = new Random();
        for( int i = 0 ; i < length ; i++ ){
            sb.append( charaters[ rn.nextInt( charaters.length ) ] );
        }
        return sb.toString();
    }
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String discountId = request.getParameter("discountId");
		String facilityChargeName = request.getParameter("facilityChargeId");
		String discountName = request.getParameter("discountName");
		String discountRate = request.getParameter("discountRate");
		String discountStdt = request.getParameter("discountStdt");
		String discountEnddt = request.getParameter("discountEnddt");
		
		if(facilityChargeName.isEmpty()||discountName.isEmpty()||discountRate.isEmpty()||discountStdt.isEmpty()||discountEnddt.isEmpty()) {
			request.setAttribute("error", "��ĭ�� �ֽ��ϴ�. �ٽ� �Է��ϼ���.");
			HttpUtil.forward(request, response, "/DiscountEnroll.jsp");
			return;
		}
		
		Discount discount = new Discount();
		//discount.setDiscountId(discountId);
		discount.setDiscountId(getRandomDiscountId(15));
		discount.setFacilityChargeId(facilityChargeName);
		discount.setDiscountName(discountName);
		discount.setDiscountRate(Float.parseFloat(discountRate));
		discount.setDiscountStdt(discountStdt);
		discount.setDiscountEnddt(discountEnddt);
		
		DiscountService service = DiscountService.getInstance();
		service.DiscountEnroll(discount);
		
		request.setAttribute("discountId", discountId);
		HttpUtil.forward(request, response, "/result/DiscountEnrollResult.jsp");
		
	}
}
