package sys.DiscountManagement.controller;
import sys.Controller;
import sys.HttpUtil;



import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class DiscountDeleteController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("discountId");
		DiscountService service = DiscountService.getInstance();
		service.DiscountDelete(id);
		
		HttpUtil.forward(request, response, "/result/DiscountDeleteResult.jsp");
		
	}

}
