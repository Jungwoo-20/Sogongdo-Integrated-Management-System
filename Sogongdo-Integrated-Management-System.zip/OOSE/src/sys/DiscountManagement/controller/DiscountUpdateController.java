package sys.DiscountManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.DiscountManagement.model.*;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DiscountUpdateController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String discountId = request.getParameter("discountId");
		String facilityChargeId = request.getParameter("facilityChargeId");
		String discountName = request.getParameter("discountName");
		String discountRate = request.getParameter("discountRate");
		String discountStdt = request.getParameter("discountStdt");
		String discountEnddt = request.getParameter("discountEnddt");
		
		if(discountName.isEmpty()||discountRate.isEmpty()||discountStdt.isEmpty()||discountEnddt.isEmpty()) {
			request.setAttribute("error", "��ĭ�� �ֽ��ϴ�. �ٽ� �Է��ϼ���.");
			HttpUtil.forward(request, response, "/DiscountUpdate.jsp");
			return;
		}
		
		Discount discount = new Discount();
		discount.setDiscountId(discountId);
		discount.setFacilityChargeId(facilityChargeId);
		discount.setDiscountName(discountName);
		discount.setDiscountRate(Float.parseFloat(discountRate));
		discount.setDiscountStdt(discountStdt);
		discount.setDiscountEnddt(discountEnddt);
		
		DiscountService service = DiscountService.getInstance();
		service.DiscountUpdate(discount);
		
		request.setAttribute("discountId", discountId);
		request.setAttribute("facilityChargeId", facilityChargeId);
		HttpUtil.forward(request, response, "/result/DiscountUpdateResult.jsp");
	}
	
}
