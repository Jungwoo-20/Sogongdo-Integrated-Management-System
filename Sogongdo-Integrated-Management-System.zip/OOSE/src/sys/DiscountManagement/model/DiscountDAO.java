package sys.DiscountManagement.model;

import java.sql.*;
import java.util.ArrayList;

import sys.Dao;

public class DiscountDAO extends Dao{
	private static DiscountDAO dao = new DiscountDAO();
	private DiscountDAO() {}
	public static DiscountDAO getInstance() {
		return dao;
	}

	
	public void DiscountEnroll(Discount discount) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = connect();
			
			pstmt = conn.prepareStatement("select * from oose.facilityCharge where buyerType=?");
			pstmt.setString(1, discount.getFacilityChargeId());
			String facilityChargeId="";
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				facilityChargeId = rs.getString("facilityChargeId");
			}
			pstmt.close();
			
			pstmt = conn.prepareStatement("insert into oose.discount values(?,?,?,?,?,?)");
			pstmt.setString(1, discount.getDiscountId());
			pstmt.setString(2, facilityChargeId);
			pstmt.setString(3, discount.getDiscountName());
			pstmt.setFloat(4, discount.getDiscountRate());
			pstmt.setString(5, discount.getDiscountStdt());
			pstmt.setString(6, discount.getDiscountEnddt());
			pstmt.executeUpdate();
			
		}catch(Exception ex) {
			System.out.println("DB insert ����" + ex);
		}finally {
			close(conn,pstmt);
		}
	}
	
	public ArrayList<Discount> getDiscountList(){
		ArrayList<Discount> Dlist = new ArrayList<Discount>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Discount discount =null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from oose.discount");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				discount = new Discount();
				discount.setDiscountId(rs.getString(1));
				discount.setFacilityChargeId(rs.getString(2));
				discount.setDiscountName(rs.getString(3));
				discount.setDiscountRate(rs.getFloat(4));
				discount.setDiscountStdt(rs.getString(5));
				discount.setDiscountEnddt(rs.getString(6));
				Dlist.add(discount);
			}
		} catch (Exception ex) {
			System.out.println("���� �߻�" + ex);
		} finally {
			close(conn, pstmt, rs);
		}
		return Dlist;
	}
	
	public void DiscountDelete(String discountId) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("delete from oose.discount where discountid=?");
			pstmt.setString(1, discountId);
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB ���� ����" + ex);
		}finally {
			close(conn,pstmt);
		}
	}
	
	
	public void DiscountUpdate(Discount discount) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("Update oose.discount set discountName=?, discountRate=?, discountStdt=?, discountEnddt=? where discountId=?");
			pstmt.setString(1, discount.getDiscountName());
			pstmt.setFloat(2, discount.getDiscountRate());
			pstmt.setString(3, discount.getDiscountStdt());
			pstmt.setString(4, discount.getDiscountEnddt());
			pstmt.setString(5, discount.getDiscountId());
			
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB ������Ʈ ����" + ex);
		}finally {
			close(conn,pstmt);
		}
	}
	

}
