package sys.DiscountManagement.model;



public class Discount {
	private String discountId;
	private String facilityChargeId;
	private String discountName;
	private float discountRate;
	private String discountStdt;
	private String discountEnddt;
	
	public String getDiscountId() {
		return discountId;
	}
	public void setDiscountId(String discountId) {
		this.discountId = discountId;
	}
	public String getFacilityChargeId() {
		return facilityChargeId;
	}
	public void setFacilityChargeId(String facilityChargeId) {
		this.facilityChargeId = facilityChargeId;
	}
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
	public float getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(float discountRate) {
		this.discountRate = discountRate;
	}
	public String getDiscountStdt() {
		return discountStdt;
	}
	public void setDiscountStdt(String discountStdt) {
		this.discountStdt = discountStdt;
	}
	public String getDiscountEnddt() {
		return discountEnddt;
	}
	public void setDiscountEnddt(String discountEnddt) {
		this.discountEnddt = discountEnddt;
	}
	
	
}
