package sys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Dao {
	public Connection connect() {
		Connection conn = null;
		
		try {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			}catch (ClassNotFoundException e) {
				
			}
		
			//DB
			String url = "jdbc:mysql://localhost:3306/oose?characterEncoding=UTF-8&allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC&useSSL=false";
			conn = DriverManager.getConnection(url, "root", "root");
		}catch(Exception ex) {
			System.out.println("���� �߻� : " + ex);
		}
	return conn;
	}	
	public void close(Connection conn, PreparedStatement ps, ResultSet rs) {
		if(rs != null) {
			try{
				rs.close();
			}catch(Exception ex) {
				System.out.println("���� �߻� : " + ex);
			}
		}
		close(conn,ps);
		}
		public void close(Connection conn, PreparedStatement ps) {
			if(ps!=null) {
				try {
					ps.close();
				}catch(Exception ex) {
					System.out.println("���� �߻� : " + ex);
				}
			}
			if(conn != null) {
				try {
					conn.close();
				}catch(Exception ex){
					System.out.println("���� �߻� : " + ex);
				}
			}
		}
		public String checkAuthority() {
			
			
			return null;
		}
}
