package sys.AuthorityManagement.controller;

import java.util.ArrayList;

import sys.AuthorityManagement.model.Authority;
import sys.AuthorityManagement.model.AuthorityDAO;



public class AuthorityService {
	private static AuthorityService service = new AuthorityService();
	public AuthorityDAO dao = AuthorityDAO.getInstance();
	
	private AuthorityService() {
		
	}
	
	public static AuthorityService getInstance() {
		return service;
	}
	
	public void AuthorityEnroll(Authority authority) {
		dao.authorityEnroll(authority);;
	}
	
	
	public void AuthorityUpdate(Authority product) {
		dao.productUpdate(product);
	}
	
	public void AuthorityDelete(String id) {
		dao.authorityDelete(id);
	}
	public ArrayList<Authority> authorityList() {
		ArrayList<Authority> list = dao.getAuthorityList();
		return list;
	}

}