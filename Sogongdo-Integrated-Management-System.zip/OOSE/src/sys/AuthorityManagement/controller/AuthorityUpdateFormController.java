package sys.AuthorityManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;
import sys.AuthorityManagement.model.Authority;

public class AuthorityUpdateFormController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String id = request.getParameter("id");
		Authority authority = new Authority();
		authority.setAuthorityId(Integer.parseInt(id));
		
		request.setAttribute("authority",authority);
		HttpUtil.forward(request, response, "/AuthorityUpdate.jsp");
	}

}