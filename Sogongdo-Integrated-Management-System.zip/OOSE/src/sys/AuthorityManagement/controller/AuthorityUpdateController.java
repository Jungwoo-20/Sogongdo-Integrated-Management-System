package sys.AuthorityManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;
import sys.AuthorityManagement.model.Authority;



public class AuthorityUpdateController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String id = request.getParameter("authorityid");
		String name = request.getParameter("name");
	
		
		
		if (name.isEmpty()) {
			request.setAttribute("error", "�ʼ� ���� ���Է�");
			HttpUtil.forward(request, response, "/AuthorityUpdate.jsp");
			return;
		}
		

		Authority authority = new Authority();
		authority.setAuthorityId(Integer.parseInt(id));
		authority.setAuthorityName(name);
		
		

		AuthorityService service = AuthorityService.getInstance();
		service.AuthorityUpdate(authority);
		
		request.setAttribute("id",id);
		HttpUtil.forward(request, response, "/result/AuthorityUpdateResult.jsp");
	}

}