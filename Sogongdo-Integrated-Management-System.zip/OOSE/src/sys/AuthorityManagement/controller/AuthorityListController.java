package sys.AuthorityManagement.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;
import sys.AuthorityManagement.controller.AuthorityService;
import sys.AuthorityManagement.model.Authority;


public class AuthorityListController implements Controller {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AuthorityService service = AuthorityService.getInstance();
		ArrayList<Authority> list = service.authorityList();
		String auth = (String)request.getSession().getAttribute("authority");
		if(auth !=null) {
			if( auth.equals("30")) {
				request.setAttribute("list", list);
				HttpUtil.forward(request, response, "/AuthorityListView.jsp");
			}
			else {
				HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
			}
		}else {
			HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
		}
	}
}