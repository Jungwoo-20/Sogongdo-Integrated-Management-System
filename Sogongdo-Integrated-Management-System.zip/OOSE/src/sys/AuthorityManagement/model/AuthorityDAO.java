package sys.AuthorityManagement.model;



import java.sql.*;
import java.util.ArrayList;

import sys.Dao;



public class AuthorityDAO extends Dao{
	private static AuthorityDAO dao = new AuthorityDAO();
	
	private AuthorityDAO() {

	}
	
	public static AuthorityDAO getInstance() {
		return dao;
	}
	
	public void authorityEnroll(Authority authority) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("insert into oose.authority values(?,?)");
			pstmt.setInt(1, authority.getAuthorityId());
			pstmt.setString(2, authority.getAuthorityName());
			
			
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB insert ����" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public ArrayList<Authority> getAuthorityList() {

		ArrayList<Authority> list = new ArrayList<Authority>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		Authority authority = null;

		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from oose.authority");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				authority = new Authority();
				authority.setAuthorityId(rs.getInt(1));
				authority.setAuthorityName(rs.getString(2));
				
				list.add(authority);
			}

		} catch (Exception ex) {
			System.out.println("���� �߻� : " + ex);
		} finally {
			close(conn, pstmt, rs);
		}

		return list;
	}
	public void authorityDelete(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("delete from oose.authority where authorityGrade=?");
			pstmt.setInt(1, Integer.parseInt(id));;
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB delete error" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public void productUpdate(Authority authority) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("Update oose.authority set authorityGradeName=? where authorityGrade=?");
			pstmt.setString(1, authority.getAuthorityName());
			pstmt.setInt(2, authority.getAuthorityId());
			
			pstmt.executeUpdate();
		}catch (Exception ex) {
			System.out.println("DB ������Ʈ ����" + ex);
		}finally {
			close(conn,pstmt);
		}
	}
	
}