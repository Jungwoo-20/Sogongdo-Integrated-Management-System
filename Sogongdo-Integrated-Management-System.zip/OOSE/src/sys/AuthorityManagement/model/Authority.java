package sys.AuthorityManagement.model;



public class Authority {
	private int authorityid;
	private String authorityName;
	


	public int getAuthorityId() {return authorityid;}
	public String getAuthorityName() {return authorityName;}
	

	public void setAuthorityId(int id) {
		authorityid=id;
	}
	public void setAuthorityName(String name) {
		authorityName=name;
	}
}