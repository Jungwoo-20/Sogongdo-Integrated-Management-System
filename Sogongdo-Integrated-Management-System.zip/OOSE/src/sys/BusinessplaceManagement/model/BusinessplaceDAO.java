package sys.BusinessplaceManagement.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import sys.Dao;

public class BusinessplaceDAO extends Dao{
	//private DataSource ds;
		
	public ArrayList<BusinessplaceDTO> businessplaceSelect() { // �������ȸ
		
		Statement st = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM businessplace";
		ArrayList<BusinessplaceDTO> list = new ArrayList<BusinessplaceDTO>();
		
		try {
			Connection conn = connect();
			
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			
			while (rs.next()) {
				String bpId = rs.getString(1);
				String bpName = rs.getString(2);
				String bpRegistedNum = rs.getString(3);
				String boss = rs.getString(4);
				String address = rs.getString(5);
				String tel = rs.getString(6);
				String type = rs.getString(7);
				int scale = rs.getInt(8);
				String managerId = rs.getString(9);
				BusinessplaceDTO dto = new BusinessplaceDTO(bpId,bpName,bpRegistedNum,
						boss,address,tel,type,scale,managerId);
				list.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public void businessplaceEnroll(BusinessplaceDTO item) { // �������
		try {
			Connection conn = connect();
			
			ResultSet rs = null;
			PreparedStatement pstmt = null;
			
			String sql = "INSERT INTO businessplace(businessplaceId,businessplaceName,registedNum,"
					+ "boss,address,tel,type,scale,managerId)"
					+ "VALUES (?,?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
		
					pstmt.setString(1, item.getBusinessplaceId());
					pstmt.setString(2, item.getBusinessplaceName());
					pstmt.setString(3, item.getRegistedNum());
					pstmt.setString(4, item.getBoss());
					pstmt.setString(5, item.getAddress());
					pstmt.setString(6, item.getTel());
					pstmt.setString(7, item.getType());
					pstmt.setInt(8, item.getScale());
					pstmt.setString(9, item.getManagerId());
					
					pstmt.executeUpdate();
				}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void businessplaceUpdate(BusinessplaceDTO item) { // ��������
		try {
			Connection conn = connect();
			System.out.println("DB������Ʈ..");
			ResultSet rs = null;
			Statement stmt = null;

			stmt = conn.createStatement();
			String sql = "";
			
			if(item.getBusinessplaceName() != null) {
				sql = "Update businessplace set businessplaceName='"+item.getBusinessplaceName() // ������ ��
						+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
			}
			
			if(item.getRegistedNum() != null) {
				sql = "Update businessplace set registedNum='"+item.getRegistedNum() // ������ ��
				+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
			}
			
			if(item.getBoss() != null) {
				sql = "Update businessplace set boss='"+item.getBoss() // ������ ��
				+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
			}
		
			if(item.getTel() != null) {
				sql = "Update businessplace set tel='"+item.getTel() // ������ ��
				+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
			}
			
			if(item.getAddress() != null) {
				sql = "Update businessplace set address='"+item.getAddress() // ������ ��
				+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
			}
			
			if(item.getType() != null) {
				sql = "Update businessplace set type='"+item.getType() // ������ ��
				+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
			}
			
			if(item.getScale() != 0) {
				sql = "Update businessplace set scale='"+item.getScale() // ������ ��
				+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
				}
			
			if(item.getManagerId() != null) {
				sql = "Update businessplace set managerId='"+item.getManagerId() // ������ ��
				+ "' where businessplaceId='"+item.getBusinessplaceId()+"'";

				stmt.executeUpdate(sql);
				}
			
			}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(item.getBoss());
	}
	
	public void businessplaceDelete(ArrayList<String> bpIdlist) { // ��������
		try {
			Connection conn = connect();
			ResultSet rs = null;
			Statement stmt = null;
			stmt = conn.createStatement();
			
			for(int i = 0; i < bpIdlist.size(); i++) {
				String businessplaceId = bpIdlist.get(i);
				String sql = "delete from businessplace where businessplaceId='"+businessplaceId+"'";
			
				stmt.execute(sql);
			}
			
			}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public BusinessplaceDTO getBusinessplace(String parameter) {
		try {
			Connection conn = connect();
			ResultSet rs = null;
			Statement stmt = null;
			stmt = conn.createStatement();
			
			String sql = "select * from businessplace where businessplaceId="+parameter+";";
			rs = stmt.executeQuery(sql);
			BusinessplaceDTO dto = null;
			
			while(rs.next()) {
			dto = new BusinessplaceDTO(rs.getString(1),rs.getString(2),rs.getString(3),
					rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getInt(8),
					rs.getString(9));
			}
			return dto;
			
			}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
	
public ArrayList<BPAttributeDTO> BPAttributeSelect(String parm) { // �������ȸ
		
		
		Statement st = null;
		ResultSet rs = null;
		
		try {
			Connection conn = connect();
			st = conn.createStatement();
			
			String sql = "SELECT businessplaceName FROM businessplace where businessplaceId='"+parm+"'";
			rs = st.executeQuery(sql);
			
			String bpName = "";
			
			while(rs.next()) {
				bpName= rs.getString(1);
			}
			
			System.out.println(parm);
			
			sql = "SELECT * FROM businessattribute where businessplaceId='"+parm+"'";
			rs = st.executeQuery(sql);
			ArrayList<BPAttributeDTO> list = new ArrayList<BPAttributeDTO>();
			
			while (rs.next()) {
				String bpaId = rs.getString(1);
				String bpId = rs.getString(2);
				String bpaName = rs.getString(3);
				String value = rs.getString(4);
				
				BPAttributeDTO dto = new BPAttributeDTO(bpaId,parm,bpaName, value);
				dto.setBPName(bpName);
				list.add(dto);
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public void BPAttributeEnroll(BPAttributeDTO item) { // �������
		try {
			Connection conn = connect();
			ResultSet rs = null;
			PreparedStatement pstmt = null;
			
			String sql = "INSERT INTO businessattribute(businessAttributeId,businessplaceId,"
					+ "businessAttributeName,"
					+ "value)"
					+ "VALUES (?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
		
					pstmt.setString(1, item.getBPAttributeId());
					pstmt.setString(2, item.getBusinessplaceId());
					pstmt.setString(3, item.getBPAttributeName());
					pstmt.setString(4, item.getBPAValue());
					
					pstmt.executeUpdate();
				}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void BPAttributeUpdate(BPAttributeDTO item) { // ��������
		try {
			Connection conn = connect();
			ResultSet rs = null;
			Statement stmt = null;

			stmt = conn.createStatement();
			String sql = "";
			
			if(item.getBPAttributeName()!= null) {
				sql = "Update businessattribute set businessAttributeName='"+item.getBPAttributeName() // ������ ��
						+ "' where businessAttributeId='"+item.getBPAttributeId()+"'";

				stmt.executeUpdate(sql);
			}
			
			if(item.getBPAValue()!= null) {
				sql = "Update businessattribute set value='"+item.getBPAValue() // ������ ��
						+ "' where businessAttributeId='"+item.getBPAttributeId()+"'";

				stmt.executeUpdate(sql);
			}
			
			
			}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public void BPAttributeDelete(ArrayList<String> bpaIdlist) { // ��������
		try {
			Connection conn = connect();
			ResultSet rs = null;
			Statement stmt = null;
			stmt = conn.createStatement();
			
			for(int i = 0; i < bpaIdlist.size(); i++) {
				String bpaId = bpaIdlist.get(i);
				String sql = "delete from businessattribute where businessAttributeId='"+bpaId+"'";
			
				stmt.execute(sql);
			}
			
			}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public BPAttributeDTO getBPAttribute(String parameter) {
		try {
			Connection conn = connect();
			ResultSet rs = null;
			Statement stmt = null;
			stmt = conn.createStatement();
			
			String sql = "select * from businessattribute where businessAttributeId="+parameter+";";
			rs = stmt.executeQuery(sql);
			BPAttributeDTO dto = null;
			
			while(rs.next()) {
			dto = new BPAttributeDTO(rs.getString(1),rs.getString(2),rs.getString(3),
					rs.getString(4));
			}
			return dto;
			
			}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}

	public String foundBusinessplaceName(String bpId) {
		// TODO Auto-generated method stub
		try {
			Connection conn = connect();
			ResultSet rs = null;
			Statement stmt = null;
			stmt = conn.createStatement();
			
			String sql = "select businessplaceName from businessplace where businessplaceId="+bpId+";";
			rs = stmt.executeQuery(sql);

			String data = "";
			
			while(rs.next()) {
				data = rs.getString(1);
			}
			System.out.println(data);
			return data;
			}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
	
	public boolean confirmBusinessplace(String id) {
		boolean result = false;
		try {
			Connection conn = connect();
			ResultSet rs = null;
			PreparedStatement pstmt = null;
			
			String sql = "select businessplaceName from businessplace where businessplaceId=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			String data = "";
			
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		}	
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return false;
		}
	}
	
	public boolean confirmBPAttributeId(String id) {
		boolean result = false;
		try {
			
			Connection conn = connect();
			ResultSet rs = null;
			PreparedStatement pstmt = null;
			
			String sql = "select* from businessattribute where businessAttributeId=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			String data = "";
			
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		}	
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return false;
		}
	}
	
	public boolean confirmManagerId(String id) {
		boolean result = false;
		try {
			
			Connection conn = connect();
			
			ResultSet rs = null;
			PreparedStatement pstmt = null;
			
			String sql = "select * from `member` where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			String data = "";
			
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		}	
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return false;
		}
	}
}
