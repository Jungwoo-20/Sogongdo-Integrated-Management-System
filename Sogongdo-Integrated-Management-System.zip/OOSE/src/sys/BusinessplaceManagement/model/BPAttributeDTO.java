package sys.BusinessplaceManagement.model;

public class BPAttributeDTO {

	private String BPAttributeId;
	private String businessplaceId;
	private String BPAttributeName;
	private String BPAValue;
	private String BPName;
	

	public BPAttributeDTO(String bPAttributeId, String businessplaceId, String bPAttributeName, String bPAValue) {
		super();
		BPAttributeId = bPAttributeId;
		this.businessplaceId = businessplaceId;
		BPAttributeName = bPAttributeName;
		BPAValue = bPAValue;
	}

	public String getBPName() {
		return BPName;
	}

	public void setBPName(String bPName) {
		BPName = bPName;
	}
	public String getBPAttributeId() {
		return BPAttributeId;
	}
	public void setBPAttributeId(String bPAttributeId) {
		BPAttributeId = bPAttributeId;
	}
	public String getBusinessplaceId() {
		return businessplaceId;
	}
	public void setBusinessplaceId(String businessplaceId) {
		this.businessplaceId = businessplaceId;
	}
	public String getBPAttributeName() {
		return BPAttributeName;
	}
	public void setBPAttributeName(String bPAttributeName) {
		this.BPAttributeName = bPAttributeName;
	}
	public String getBPAValue() {
		return BPAValue;
	}
	public void setBPAValue(String bPAValue) {
		this.BPAValue = bPAValue;
	}
}
