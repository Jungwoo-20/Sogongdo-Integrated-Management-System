package sys.BusinessplaceManagement.model;

public class BusinessplaceDTO {
	
	private String businessplaceId;
	private String businessplaceName;
	private String registedNum;
	private String boss;
	private String address;
	private String tel;
	private String type;
	private int scale;
	private String managerId;
	
	public BusinessplaceDTO(String businessplaceId, String businessplaceName, String registedNum, String boss,
			String address, String tel, String type, int scale, String managerId) {
		super();
		this.businessplaceId = businessplaceId;
		this.businessplaceName = businessplaceName;
		this.registedNum = registedNum;
		this.boss = boss;
		this.address = address;
		this.tel = tel;
		this.type = type;
		this.scale = scale;
		this.managerId = managerId;
	}
	
	public String getBusinessplaceId() {
		return businessplaceId;
	}
	public void setBusinessplaceId(String businessplaceId) {
		this.businessplaceId = businessplaceId;
	}
	public String getBusinessplaceName() {
		return businessplaceName;
	}
	public void setBusinessplaceName(String businessplaceName) {
		this.businessplaceName = businessplaceName;
	}
	public String getRegistedNum() {
		return registedNum;
	}
	public void setRegistedNum(String registedNum) {
		this.registedNum = registedNum;
	}
	public String getBoss() {
		return boss;
	}
	public void setBoss(String boss) {
		this.boss = boss;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getScale() {
		return scale;
	}
	public void setScale(int scale) {
		this.scale = scale;
	}
	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	
	
	
}
