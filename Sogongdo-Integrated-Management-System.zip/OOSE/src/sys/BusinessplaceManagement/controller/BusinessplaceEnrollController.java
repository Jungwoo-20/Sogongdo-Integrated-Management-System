package sys.BusinessplaceManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;

@WebServlet("/EnrollBP")
public class BusinessplaceEnrollController extends HttpServlet implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    
		res.setContentType("text/html; charset=EUC-KR");
	    req.setCharacterEncoding("EUC-KR");
	    
	    String bpId = req.getParameter("bpId");   
	    BusinessplaceDAO dao = new BusinessplaceDAO(); // �ӽ�
	    
	    boolean confirm = dao.confirmBusinessplace(bpId);
	    //confirmBPAttributeId
	    
	    if(confirm) { // �ߺ�
	    	req.setAttribute("CHECK", "NO");
			HttpUtil.forward(req, res, "/confirmBusinessplaceId.jsp");
			return;
	    }
	    
		String bpName = req.getParameter("name");
		String rNum = req.getParameter("rNum");
		String boss = req.getParameter("boss");
		String address = req.getParameter("ad");
		String tel = req.getParameter("tel");
		String type = req.getParameter("type");

		int scale = 0;
		if((req.getParameter("scale")).equals("")) {
			System.out.println("scale null");
			scale = 0;
		}
		else {
			scale = Integer.parseInt(req.getParameter("scale"));
		}
		
		String mgId = req.getParameter("mgId");
		confirm = dao.confirmManagerId(mgId);
		
		if(!confirm) { // ���� X
	    	req.setAttribute("CHECK", "YES");
			HttpUtil.forward(req, res, "/confirmManagerId.jsp");
	    	return;
	    }
		else {
			req.setAttribute("CHECK", "NO");
			HttpUtil.forward(req, res, "/confirmManagerId.jsp");
			
			BusinessplaceDTO newDto = new BusinessplaceDTO(bpId, bpName, rNum, boss, address,
											tel, type, scale, mgId);
			BusinessplaceService service = new BusinessplaceService();
		    service.businessplaceEnroll(newDto);
				
			System.out.println("Businessplace�� ����մϴ� ...");
		}
		}
}
