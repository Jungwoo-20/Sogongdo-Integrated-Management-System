package sys.BusinessplaceManagement.controller;

import java.util.ArrayList;

import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;

public class BPAService {
	
	public BusinessplaceDAO dao = new BusinessplaceDAO();
	
	public void BPAttributeEnroll(BPAttributeDTO item) {
		dao.BPAttributeEnroll(item);
	}
	
	public void BPAttributeUpdate(BPAttributeDTO item) {
		dao.BPAttributeUpdate(item);
	}
	
	public void BPAttributeDelete(ArrayList<String> id) {
		dao.BPAttributeDelete(id);
	}
	
	public ArrayList<BPAttributeDTO> BPAttributeSelect(String parm) {
		ArrayList<BPAttributeDTO> list = dao.BPAttributeSelect(parm);
		return list;
	}

	public String foundBusinessplaceName(String bpId) {
		return dao.foundBusinessplaceName(bpId);
	}
}
