package sys.BusinessplaceManagement.controller;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.util.*;

import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;

@WebServlet("/BP")

public class BusinessplaceFrontController extends HttpServlet{ // Client�� ��û�� �޴� Front
	
	private static final long serialVersionUID = 1L;
	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		//charset = config.getInitParameter("charset");
		list = new HashMap<String, Controller>(); // key, value
		list.put("/EnrollBP.BP",  new BusinessplaceEnrollController());
		list.put("/UpdateBP.BP",  new BusinessplaceUpdateController());
		list.put("/DisplayBP.BP" , new BusinessplaceDisplayController());
	}
	
	@Override
	// http request url�� ���� controller ����
	public void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{

		String url = request.getRequestURI();

		String contextPath = request.getContextPath();
		
		String path = url.substring(contextPath.length());
		
		Controller subController = list.get(path);
		subController.execute(request, response);
	}
}