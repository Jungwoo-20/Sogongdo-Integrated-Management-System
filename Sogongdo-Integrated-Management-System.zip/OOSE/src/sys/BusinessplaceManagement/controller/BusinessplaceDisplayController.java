package sys.BusinessplaceManagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;


@WebServlet("/bpDisplay")
public class BusinessplaceDisplayController extends HttpServlet implements Controller{

	BusinessplaceService service = new BusinessplaceService();
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		String auth = (String)req.getSession().getAttribute("authority");
		if(auth !=null) {
		if(auth.equals("20") || auth.equals("40") || auth.equals("50")) {
			ArrayList<BusinessplaceDTO> list = service.businessplaceSelect();
			req.setAttribute("list", list);
			System.out.println("��ϵ� �����: " + list.size());
				
			HttpUtil.forward(req, res, "/DisplayBusinessplaceView.jsp");
		}
		else {
			HttpUtil.forward(req, res, "/DisplayBusinessplaceViewResult.jsp");
		}
		}else {
			HttpUtil.forward(req, res, "/DisplayBusinessplaceViewResult.jsp");
		}
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    res.setContentType("text/html; charset=UTF-8");
	    req.setCharacterEncoding("utf-8");
	    
	    String[] cb = req.getParameterValues("checkbox"); 
	    
	    if(cb != null) {
		ArrayList<String> deList = new ArrayList();
		
		for(int i = 0; i < cb.length; i++) {
			deList.add(cb[i]);
			System.out.println(cb[i]);
		}
		service.businessplaceDelete(deList);
		System.out.println("List�� �����մϴ� ...");
		
	    }
	    else {
	    	System.out.println("�׸��� ���õ��� �ʾҽ��ϴ� ...");
	    }
	    
		execute(req, res);
	    }
}
