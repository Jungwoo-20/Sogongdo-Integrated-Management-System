package sys.BusinessplaceManagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;

@WebServlet("/UpdateBP")
public class BusinessplaceUpdateController extends HttpServlet implements Controller{
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		BusinessplaceDAO dao = new BusinessplaceDAO();
		String bpId = req.getParameter("id");
		BusinessplaceDTO exDto = dao.getBusinessplace(bpId);
		
		req.setAttribute("bpDTO", exDto);

		HttpUtil.forward(req, res, "/UpdateBusinessplaceView.jsp"); // ������ ���� ( ���� ����)
		System.out.println("UpdateBusinessplaceView.jsp������ DTO�� �����մϴ� ...");
		
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    
		res.setContentType("text/html; charset=EUC-KR");
	    req.setCharacterEncoding("EUC-KR");
	    
	    String bpId = req.getParameter("bpId");
	 
	    
		String bpName = req.getParameter("name");
		String rNum = req.getParameter("rNum");
		String boss = req.getParameter("boss");
		String address = req.getParameter("ad");
		String tel = req.getParameter("tel");
		String type = req.getParameter("type");
		int scale = Integer.parseInt(req.getParameter("scale"));
		String mgId = req.getParameter("mgId");
		System.out.println(mgId);
		
	    BusinessplaceDTO newDto = new BusinessplaceDTO(bpId, bpName, rNum, boss, address,
	    		tel, type, scale, mgId);
		BusinessplaceService service = new BusinessplaceService();
		service.businessplaceUpdate(newDto);
		
		System.out.println("Businessplace�� �����մϴ� ...");
		
		HttpUtil.forward(req, res, "/ResultBusinessplaceUpdate.jsp"); 
		//execute(req, res);
	    }
}
