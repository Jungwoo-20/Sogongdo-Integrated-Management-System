package sys.BusinessplaceManagement.controller;

import java.util.ArrayList;

import sys.BusinessplaceManagement.model.BusinessplaceDAO;
import sys.BusinessplaceManagement.model.BusinessplaceDTO;


public class BusinessplaceService {
	
		public BusinessplaceDAO dao = new BusinessplaceDAO();
		
		public void businessplaceEnroll(BusinessplaceDTO product) {
			dao.businessplaceEnroll(product);
		}
		
		public void businessplaceUpdate(BusinessplaceDTO dto) {
			dao.businessplaceUpdate(dto);
		}
		
		public void businessplaceDelete(ArrayList<String> id) {
			dao.businessplaceDelete(id);
		}
		
		public ArrayList<BusinessplaceDTO> businessplaceSelect() {
			ArrayList<BusinessplaceDTO> list = dao.businessplaceSelect();
			return list;
		}
	}
