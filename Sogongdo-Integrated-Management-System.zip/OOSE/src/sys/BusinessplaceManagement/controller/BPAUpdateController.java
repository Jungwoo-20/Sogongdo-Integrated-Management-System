package sys.BusinessplaceManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;

@WebServlet("/UpdateBPA")
public class BPAUpdateController extends HttpServlet implements Controller{
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		BusinessplaceDAO dao = new BusinessplaceDAO();
		String bpaId = req.getParameter("id");
		BPAttributeDTO exDto = dao.getBPAttribute(bpaId);
		
		req.setAttribute("bpaDTO", exDto);

		HttpUtil.forward(req, res, "/UpdateBPAttributeView.jsp"); // ������ ���� ( ���� ����)
		System.out.println("UpdateBPAttributeView.jsp������ DTO�� �����մϴ� ...");
		
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    
		res.setContentType("text/html; charset=EUC-KR");
	    req.setCharacterEncoding("EUC-KR");
	    

		String bpaId = req.getParameter("bpaId"); // ���� X
	    String bpId = req.getParameter("bpId"); // ���� X
		String name = req.getParameter("name");
		String value = req.getParameter("value");
		
		if(name.equals("") && value.equals("")) { // 
			System.out.println("������ ������ �����ϴ�.");
		} // �ߺ��˻�
		
		else{
		    BPAttributeDTO newDto = new BPAttributeDTO(bpaId, bpId, name, value);
			BPAService service = new BPAService();
			service.BPAttributeUpdate(newDto);
			
			System.out.println("BPAttribute�� �����մϴ� ...");
			req.setAttribute("bpId", bpId);
			HttpUtil.forward(req, res, "/ResultBPAttributeUpdate.jsp"); 
		}
		//HttpUtil.forward(req, res, "/UpdateBusinessplaceView.jsp"); 
		//execute(req, res);
	    }
}
