package sys.BusinessplaceManagement.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;


@WebServlet("/BPADisplay")
public class BPADisplayController  extends HttpServlet implements Controller{

	BPAService service = new BPAService();
	
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    
		String bpId = "";
		
		if(req.getParameter("id") != null) { // id���� �޾ƿ��� ���ž���, �׷���������(������� ��) ������ ������ id���
			bpId = req.getParameter("id");
		}
		
		ArrayList<BPAttributeDTO> list = service.BPAttributeSelect(bpId);
		
		req.setAttribute("list", list);
		
		String bp = service.foundBusinessplaceName(bpId);
		req.setAttribute("bp", bp);
		req.setAttribute("bpId", bpId);
		
		HttpUtil.forward(req, res, "/DisplayBPAttributeView.jsp");
	}

	public void execute(HttpServletRequest req, HttpServletResponse res, String bpId) throws ServletException, IOException {
		
		ArrayList<BPAttributeDTO> list = service.BPAttributeSelect(bpId);
		
		req.setAttribute("list", list);
		
		String bp = service.foundBusinessplaceName(bpId);
		req.setAttribute("bp", bp);
		req.setAttribute("bpId", bpId);
		
		HttpUtil.forward(req, res, "/DisplayBPAttributeView.jsp");
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    
		res.setContentType("text/html; charset=EUC-KR");
	    req.setCharacterEncoding("EUC-KR");
	    
	    String[] cb = req.getParameterValues("checkbox"); 
	    if(cb != null) {
		ArrayList<String> deList = new ArrayList();
		
		for(int i = 0; i < cb.length; i++) {
			deList.add(cb[i]);
		}
		service.BPAttributeDelete(deList);
		
		
	    }
		    System.out.println("bpId: " + req.getParameter("bpId"));
			execute(req, res, req.getParameter("bpId"));
	    }
}

