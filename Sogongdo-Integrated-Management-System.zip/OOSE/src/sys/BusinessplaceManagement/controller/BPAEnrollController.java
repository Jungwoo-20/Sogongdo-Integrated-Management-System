package sys.BusinessplaceManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sys.HttpUtil;
import sys.BusinessplaceManagement.model.*;
import sys.Controller;

@WebServlet("/EnrollBPA")
public class BPAEnrollController extends HttpServlet implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		res.setContentType("text/html; charset=EUC-KR");
	    req.setCharacterEncoding("EUC-KR");

		BPAService service = new BPAService();
		
		String bpId = (req.getParameter("bpId")).toString();
		String bpName = service.foundBusinessplaceName(bpId);
		req.setAttribute("bpId", bpId);
		req.setAttribute("bpName", bpName);
		
		HttpUtil.forward(req, res, "/EnrollBPAttributeView.jsp"); 
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	    
		res.setContentType("text/html; charset=EUC-KR");
	    req.setCharacterEncoding("EUC-KR");
	    
	    String atid = req.getParameter("id");
	    String bpid = req.getParameter("bpId");
		String name = req.getParameter("name");
		String value = req.getParameter("value");
		
		BusinessplaceDAO dao = new BusinessplaceDAO(); // �ӽ�
		    
		boolean confirm = dao.confirmBPAttributeId(atid);
		    
		 if(confirm) { // �ߺ�
		    	req.setAttribute("CHECK", "NO");
		    	req.setAttribute("bpId", bpid);
				HttpUtil.forward(req, res, "/confirmBPAttributeId.jsp");
		    	return;
		    }
		
		else{
			req.setAttribute("CHECK", "YES");
			req.setAttribute("bpId", bpid);
			HttpUtil.forward(req, res, "/confirmBPAttributeId.jsp");
			
			BPAttributeDTO newDto = new BPAttributeDTO(atid, bpid, name, value);
			BPAService service = new BPAService();
			service.BPAttributeEnroll(newDto);
			
			System.out.println("Attribute�� ����մϴ� ...");
			}
	    }
}