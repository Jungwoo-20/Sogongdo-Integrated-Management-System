package sys.AccommodationRefundManagement.model;

public class AccommodationRefundDTO {
	private int accommodationRefundID;			// ���� ȯ�� ID
	private int accommodationPaymentID;			// ���� ���� ID
	private int accommodationRefundAmount;		// ���� ȯ�� �ݾ�
	private String accommodationRefundAccount;		// ���� ȯ�� ����
	private boolean isDelete;						// ���� ����
	
	public AccommodationRefundDTO(int accommodationRefundID, int accommodationPaymentID, int accommodationRefundAmount,
			String accommodationRefundAccount, boolean isDelete) {
		super();
		this.accommodationRefundID = accommodationRefundID;
		this.accommodationPaymentID = accommodationPaymentID;
		this.accommodationRefundAmount = accommodationRefundAmount;
		this.accommodationRefundAccount = accommodationRefundAccount;
		this.isDelete = isDelete;
	}
	
	public int getAccommodationRefundID() {
		return accommodationRefundID;
	}
	public void setAccommodationRefundID(int accommodationRefundID) {
		this.accommodationRefundID = accommodationRefundID;
	}
	public int getAccommodationPaymentID() {
		return accommodationPaymentID;
	}
	public void setAccommodationPaymentID(int accommodationPaymentID) {
		this.accommodationPaymentID = accommodationPaymentID;
	}
	public int getAccommodationRefundAmount() {
		return accommodationRefundAmount;
	}
	public void setAccommodationRefundAmount(int accommodationRefundAmount) {
		this.accommodationRefundAmount = accommodationRefundAmount;
	}
	public String getAccommodationRefundAccount() {
		return accommodationRefundAccount;
	}
	public void setAccommodationRefundAccount(String accommodationRefundAccount) {
		this.accommodationRefundAccount = accommodationRefundAccount;
	}
	public boolean isDelete() {
		return isDelete;
	}
	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}
	
}