package sys.AccommodationRefundManagement.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;


import sys.Dao;


public class AccommodationRefundDAO extends Dao{
	// �̱���
	private static AccommodationRefundDAO _instance;
	
	private AccommodationRefundDAO() {
	}
	
	public static AccommodationRefundDAO getInstance() {
		if(_instance == null) {
			_instance = new AccommodationRefundDAO();
		}
		return _instance;
	}
	
	
	public ArrayList<AccommodationRefundDTO> select(final ArrayList<String> columns, final String where) {
		Connection connection = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = null;
		ArrayList<AccommodationRefundDTO> result = new ArrayList<AccommodationRefundDTO>();
		
		try {
			// ������ ������ �� ����
			StringBuilder sb = new StringBuilder();
			for(String column : columns) {
				sb.append(column + ", ");
			}
			sb.delete(sb.length() - 2, sb.length() - 1);
			String columnsStr = sb.toString();
			
			// ���ǹ� ����
			String whereStr = "";
			if(where != null) {
				whereStr = " WHERE " + where;
			}
			
			// ������ �ϼ�
			sql = "SELECT " + columnsStr + " FROM " + "oose.accommodationrefund" + whereStr;
			
			connection = connect();
			
			try {
				st = connection.createStatement();
				rs = st.executeQuery(sql);
				while(rs.next()) {
					int id = rs.getInt("accommodationRefundID");
					int reservationID = rs.getInt("accommodationPaymentID");
					int refundAmount = rs.getInt("accommodationRefundAmount");
					String refundAccount = rs.getString("accommodationRefundAccount");
					boolean isDelete = rs.getBoolean("isDelete");
					
					AccommodationRefundDTO dto = new AccommodationRefundDTO(id, reservationID, refundAmount, refundAccount, isDelete);
					result.add(dto);
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		finally {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			closeConnection(connection);
		}
		
		
		// �迭 �ȿ� ������ ��������� ��ȯ, �� �迭�̸� null ��ȯ
		return result.size() > 0 ? result : null;
	}
	
	
	public int enroll(final AccommodationRefundDTO dto) {
		Connection connection = null;
		String sql = null;
		
		try {
			sql = "INSERT INTO " + "oose.accommodationrefund" + " VALUES (?,?,?,?,?)";
			
			connection = connect();
			
			PreparedStatement ps = connection.prepareStatement(sql);
			if(dto.getAccommodationRefundID() <= 0) {
				// ID�� ���������(0 ����) null�� ����. �̷��� ID�� ��� ä DB�� �״�� ������, AutoIncrement�� ���� ID�� �ڵ�������.
				ps.setNull(1, Types.INTEGER);
			}
			else {
				ps.setInt(1, dto.getAccommodationRefundID());
			}
			
			ps.setInt(2, dto.getAccommodationPaymentID());
			ps.setInt(3, dto.getAccommodationRefundAmount());
			ps.setString(4, dto.getAccommodationRefundAccount());
			ps.setBoolean(5, dto.isDelete());
			
			ps.executeUpdate();
			return 1;		//SUCCEED
		}
		catch (Exception e) {
			e.printStackTrace();
			return -1;		// UNKNOWN
		}
		finally {
			closeConnection(connection);
		}
	}
	
	public int delete(final AccommodationRefundDTO dto) {
		Connection connection = null;
		String sql = null;
		
		try {	
			sql = "UPDATE " + "oose.accommodationrefund" + " SET "
					+ "isDelete" + " = ?"
					+ " WHERE " + "accommodationRefundID" + " = ?";
		
			connection = connect();
			
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setBoolean(1, true);
			ps.setInt(2, dto.getAccommodationRefundID());
			
			ps.executeUpdate();
			
			return 1;		//SUCCEED
		}
		catch (Exception e) {
			e.printStackTrace();
			return -1;		// UNKNOWN
		}
		finally {
			closeConnection(connection);
		}
	}
	
	public int update(final AccommodationRefundDTO dto) {
		Connection connection = null;
		String sql = null;
		
		try {	
			sql = "UPDATE " + "oose.accommodationrefund" + " SET "
						+ "accommodationPaymentID" + " = ?, "
						+ "accommodationRefundAmount" + " = ?, "
						+ "accommodationRefundAccount" + " = ?, "
						+ "isDelete" + " = ?"
						+ " WHERE " + "accommodationRefundID" + " = ?";
			
			connection = connect();
			
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setInt(1, dto.getAccommodationPaymentID());
			ps.setInt(2, dto.getAccommodationRefundAmount());
			ps.setString(3, dto.getAccommodationRefundAccount());
			ps.setBoolean(4, dto.isDelete());
			ps.setInt(5, dto.getAccommodationRefundID());
			
			ps.executeUpdate();
			return 1;		//SUCCEED
		}
		catch (Exception e) {
			e.printStackTrace();
			return -1;		// UNKNOWN
		}
		finally {
			closeConnection(connection);
		}
	}
	
	private void closeConnection(Connection connection) {
		if(connection != null) {
			try {
				connection.close();					
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}
}
