package sys.AccommodationRefundManagement.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.AccommodationRefundManagement.model.AccommodationRefundDTO;

public class AccommodationRefundListController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		onGet(request, response);
	}
	
	public void onGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String where = "isDelete" + " = 0";		// isDelete�� 0��(���� �ȵ�) �ֵ鸸 �����´�.
		ArrayList<AccommodationRefundDTO> accommodationRefundList = AccommodationRefundService.getInstance().accommodationPaymentList(where);
		
		request.setAttribute("AccommodationRefundList", accommodationRefundList);
		
		// Foward
		RequestDispatcher dispatcher = request.getRequestDispatcher("/DisplayAccommodationRefundView.jsp");
        dispatcher.forward(request, response);
	}

}
