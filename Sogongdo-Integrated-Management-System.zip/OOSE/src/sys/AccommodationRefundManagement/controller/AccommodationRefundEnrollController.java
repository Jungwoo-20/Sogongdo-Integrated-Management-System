package sys.AccommodationRefundManagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.AccommodationRefundManagement.model.AccommodationRefundDTO;

public class AccommodationRefundEnrollController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		onPost(request, response);
		
	}
	
	public void onGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dispatchURL = "EnrollAccommodationRefundView.jsp";
		
		// Foward
		RequestDispatcher dispatcher = request.getRequestDispatcher(dispatchURL);
        dispatcher.forward(request, response);
	}
	
	
	public void onPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String paymentIDStr = request.getParameter("accommodationPaymentID");
		String amountStr = request.getParameter("accommodationRefundAmount");
		String account = request.getParameter("accommodationRefundAccount");
		
		int paymentID = -1;
		int amount = -1;
		int result = -1;
		
		String dispatchURL = null;
		
		try {
			if(paymentIDStr != null && !paymentIDStr.isEmpty()) {
				paymentID = Integer.parseInt(paymentIDStr);
			}
			
			if(amountStr != null && !amountStr.isEmpty()) {
				amount = Integer.parseInt(amountStr);
			}
			
			AccommodationRefundDTO dto = new AccommodationRefundDTO(-1, paymentID, amount, account, false);
			
			result = AccommodationRefundService.getInstance().accommodationPaymentEnroll(dto);
			
			dispatchURL = "result/EnrollAccommodationRefundResult.jsp";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		if(result != 1) {
			String errorMsg = "�� �� ����";
			switch(result) {
			case 2:
				errorMsg = "�ܷ�Ű ����";
				break;
			case 11:
				errorMsg = "�ʼ� �׸� ����";
				break;
			case 12:
				errorMsg = "���� ����";
				break;
			case 13:
				errorMsg = "�ߺ� ����";
				break;
			case 14:
				errorMsg = "�ܷ�Ű deleted ����";
				break;
			}
			
			
			request.setAttribute("error", "���� �˻� ���� Ȥ�� ���� �߻� : " + errorMsg);
			dispatchURL = "/EnrollAccommodationRefundView.jsp";
		}
		
		// Foward
		RequestDispatcher dispatcher = request.getRequestDispatcher(dispatchURL);
        dispatcher.forward(request, response);
	}

}
