package sys.AccommodationRefundManagement.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sys.Controller;

public class AccommodationRefundFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String charset = null;
//	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config) throws ServletException{
		charset = config.getInitParameter("charset");
//		list = new HashMap<String, Controller>();
//		list.put("/EnrollAccommodationRefund.ar", new AccommodationRefundEnrollController());
//		list.put("/UpdateAccommodationRefund.ar", new AccommodationRefundUpdateController());
//		list.put("/DeleteAccommodationRefund.ar", new AccommodationRefundDeleteController());
//		list.put("/DisplayAccommodationRefund.ar", new AccommodationRefundListController());
	}
	
//	@Override
//	public void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
//		request.setCharacterEncoding(charset);
//
//		String url = request.getRequestURI();
//		
//		String contextPath = request.getContextPath();
//		
//		String path = url.substring(contextPath.length());
//				
//		Controller subController = list.get(path);
//		subController.execute(request, response);
//		
//	}
	
	// Get ��û�� �۵�
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding(charset);
		
		// ���� üũ
		if(!authorityCheck(req)) {
			// ��� �Ұ�
			req.setAttribute("error", "���� �̴�");
			String dispatchURL = "/result/ErrorPage.jsp";
			RequestDispatcher dispatcher = req.getRequestDispatcher(dispatchURL);
	        dispatcher.forward(req, resp);
			return;
		}

		String url = req.getRequestURI();
		String contextPath = req.getContextPath();
		String path = url.substring(contextPath.length());
		
		// ��ȸ�� �ٷ� ��ȸ, �������� ������ ������ �� POST �� ó���� �ٸ��� ������ ���� ������ �����ֱ⸸ ��.
		switch(path) {
			case "/DisplayAccommodationRefund.ar":
				new AccommodationRefundListController().execute(req, resp);
				return;
			case "/EnrollAccommodationRefund.ar":
				new AccommodationRefundEnrollController().onGet(req, resp);
				break;
			case "/UpdateAccommodationRefund.ar":
				new AccommodationRefundUpdateController().onGet(req, resp);
				break;
			case "/DeleteAccommodationRefund.ar":
				new AccommodationRefundDeleteController().onGet(req, resp);
				break;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding(charset);

		// ���� üũ
		if(!authorityCheck(req)) {
			// ��� �Ұ�
			req.setAttribute("error", "���� �̴�");
			String dispatchURL = "/result/ErrorPage.jsp";
			RequestDispatcher dispatcher = req.getRequestDispatcher(dispatchURL);
	        dispatcher.forward(req, resp);
			return;
		}
		
		String url = req.getRequestURI();
		String contextPath = req.getContextPath();
		String path = url.substring(contextPath.length());
		
		// ��ο� �´� �޼ҵ� ����
		switch(path) {
			case "/DisplayAccommodationRefund.ar":
				new AccommodationRefundListController().execute(req, resp);
				break;
			case "/EnrollAccommodationRefund.ar":
				new AccommodationRefundEnrollController().onPost(req, resp);
				break;
			case "/UpdateAccommodationRefund.ar":
				new AccommodationRefundUpdateController().onPost(req, resp);
				break;
			case "/DeleteAccommodationRefund.ar":
				new AccommodationRefundDeleteController().onPost(req, resp);
				break;
		}
	}
	
	private boolean authorityCheck(HttpServletRequest req) {
		// ���ǿ��� ���� ���� ȹ��
		HttpSession session = req.getSession();
		String authorityStr = (String)session.getAttribute("authority");
		
		// ��ȸ���� ��� ���� �Ұ�!
		if(authorityStr == null) {
			return false;
		}
		
		try {
			int authority = Integer.parseInt(authorityStr);
			
			// ��ȯ�� ȸ��(10) ���� ũ�� ������. ��� ����
			if(authority > 10) {
				return true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		 
		
		return false;
	}
}
