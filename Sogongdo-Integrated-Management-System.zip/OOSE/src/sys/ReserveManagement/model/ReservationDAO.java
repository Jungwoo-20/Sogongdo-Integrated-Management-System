package sys.ReserveManagement.model;

import java.sql.*;
import java.util.ArrayList;
import sys.Dao;

public class ReservationDAO extends Dao{
    private static ReservationDAO dao = new ReservationDAO();

    private ReservationDAO() { }

    public static ReservationDAO getInstance()
    {
        return dao;
    }

    public void enrollReservation(Reservation reserveInfo)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try
        {
            conn = connect();
            pstmt = conn.prepareStatement("INSERT INTO oose.reservation (`businessPlaceID`,`facilityID`,`memberID`,`reservationDate`,`startDate`,`endDate`,`contact`,`carNumber`,`status`) VALUES (?,?,?,now(),?,?,?,?,?)");
            pstmt.setString(1, reserveInfo.getBusinessPlaceID());
            pstmt.setString(2, reserveInfo.getFacilityID());
            pstmt.setString(3, reserveInfo.getMemberID());
            pstmt.setDate(4, reserveInfo.getStartDate());
            pstmt.setDate(5, reserveInfo.getEndDate());
            pstmt.setString(6, reserveInfo.getContact());
            pstmt.setString(7, reserveInfo.getCarNumber());
            pstmt.setString(8, reserveInfo.getStatus());

            pstmt.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            close(conn, pstmt);
        }
    }

    public void updateReservation(Reservation reserveInfo)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try
        {
            conn = connect();
            pstmt = conn.prepareStatement("update oose.reservation set " +
                    "businessPlaceID = ?, " +
                    "facilityID = ?, " +
                    "memberID = ?, " +
                    "startDate = ?, " +
                    "endDate = ?, " +
                    "contact = ?, " +
                    "carNumber = ?, " +
                    "status = ? where reservationID = ?");

            pstmt.setString(1, reserveInfo.getBusinessPlaceID());
            pstmt.setString(2, reserveInfo.getFacilityID());
            pstmt.setString(3, reserveInfo.getMemberID());
            pstmt.setDate(4, reserveInfo.getStartDate());
            pstmt.setDate(5, reserveInfo.getEndDate());
            pstmt.setString(6, reserveInfo.getContact());
            pstmt.setString(7, reserveInfo.getCarNumber());
            pstmt.setString(8, reserveInfo.getStatus());
            pstmt.setInt(9, reserveInfo.getReservationID());
            System.out.println(pstmt.toString());

            pstmt.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            close(conn, pstmt);
        }
    }

    public void deleteReservation(int rsvID)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try
        {
            conn = connect();
            pstmt = conn.prepareStatement("delete from oose.reservation where reservationID = ?");
            pstmt.setInt(1, rsvID);
            pstmt.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            close(conn, pstmt);
        }
    }

    public ArrayList<Reservation> getReservationList()
    {
        ArrayList<Reservation> list = new ArrayList<Reservation>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Reservation rsv = null;

        try
        {
            conn = connect();
            pstmt = conn.prepareStatement("select * from oose.reservation where status = '�����' or status = '������'");
            rs = pstmt.executeQuery();

            while(rs.next())
            {
                rsv = new Reservation();
                rsv.setReservationID(rs.getInt(1));
                rsv.setBusinessPlaceID(rs.getString(2));
                rsv.setFacilityID(rs.getString(3));
                rsv.setMemberID(rs.getString(4));
                rsv.setReserveDate(rs.getDate(5));
                rsv.setStartDate(rs.getDate(6));
                rsv.setEndDate(rs.getDate(7));
                rsv.setContact(rs.getString(8));
                rsv.setCarNumber(rs.getString(9));
                rsv.setStatus(rs.getString(10));
                rsv.setPaymentID(rs.getInt(11));

                list.add(rsv);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            close(conn, pstmt, rs);
        }

        return list;
    }

    public ArrayList<Reservation> getCanceledReservationList()
    {
        ArrayList<Reservation> list = new ArrayList<Reservation>();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Reservation rsv = null;

        try
        {
            conn = connect();
            pstmt = conn.prepareStatement("select * from oose.reservation where status = '��ҵ�'");
            rs = pstmt.executeQuery();

            while(rs.next())
            {
                rsv = new Reservation();
                rsv.setReservationID(rs.getInt(1));
                rsv.setBusinessPlaceID(rs.getString(2));
                rsv.setFacilityID(rs.getString(3));
                rsv.setMemberID(rs.getString(4));
                rsv.setReserveDate(rs.getDate(5));
                rsv.setStartDate(rs.getDate(6));
                rsv.setEndDate(rs.getDate(7));
                rsv.setContact(rs.getString(8));
                rsv.setCarNumber(rs.getString(9));
                rsv.setStatus(rs.getString(10));
                rsv.setPaymentID(rs.getInt(11));

                list.add(rsv);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            close(conn, pstmt, rs);
        }

        return list;
    }
}
