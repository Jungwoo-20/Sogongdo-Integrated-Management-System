package sys.ReserveManagement.model;


import java.sql.Date;

public class Reservation {
    private int reservationID;          // ���� ��ȣ
    private String businessPlaceID;     // ����� �̸�
    private String facilityID;          // �ü� �̸�
    private String memberID;            // ȸ�� ID
    private Date reserveDate;           // ������
    private Date startDate;             // ��� ������
    private Date endDate;               // ��� ������
    private String contact;             // ����ó
    private String carNumber;           // ���� ��ȣ
    private String status;              // ���� ����
    private int paymentID;              // ���� ���� ��ȣ

    public int getReservationID() {
        return reservationID;
    }

    public void setReservationID(int reservationID) {
        this.reservationID = reservationID;
    }

    public String getBusinessPlaceID() {
        return businessPlaceID;
    }

    public void setBusinessPlaceID(String businessPlaceID) {
        this.businessPlaceID = businessPlaceID;
    }

    public String getFacilityID() {
        return facilityID;
    }

    public void setFacilityID(String facilityID) {
        this.facilityID = facilityID;
    }

    public String getMemberID() {
        return memberID;
    }

    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    public Date getReserveDate() {
        return reserveDate;
    }

    public void setReserveDate(Date reserveDate) {
        this.reserveDate = reserveDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getCarNumber() {
        return carNumber;
    }

    public void setCarNumber(String carNumber) {
        this.carNumber = carNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(int paymentID) {
        this.paymentID = paymentID;
    }
}
