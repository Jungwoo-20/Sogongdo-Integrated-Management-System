package sys.ReserveManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.ReserveManagement.model.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class CanceledReservationEnrollController implements Controller{
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String bpID = request.getParameter("bpID");
        String facID = request.getParameter("facID");
        String memID = request.getParameter("memID");

        SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");

        Date startDate;
		try {
			startDate = new Date(fm.parse(request.getParameter("startDate")).getTime());
			Date endDate = new Date(fm.parse(request.getParameter("endDate")).getTime());
	        String contact = request.getParameter("contact");
	        String carNum = request.getParameter("carNum");

	        Reservation rsv = new Reservation();
	        rsv.setBusinessPlaceID(bpID);
	        rsv.setFacilityID(facID);
	        rsv.setMemberID(memID);
	        rsv.setStartDate(startDate);
	        rsv.setEndDate(endDate);
	        rsv.setContact(contact);
	        rsv.setCarNumber(carNum);
	        rsv.setStatus("痍⑥냼�맖");

	        ReservationService service = ReservationService.getInstance();
	        service.ReservationEnroll(rsv);

	        HttpUtil.forward(request, response, "/canceledReservationList.rsv");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
}
