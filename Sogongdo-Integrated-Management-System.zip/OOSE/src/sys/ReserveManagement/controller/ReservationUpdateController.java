package sys.ReserveManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.ReserveManagement.model.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ReservationUpdateController implements Controller
{
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id_s = request.getParameter("rsvid");
        System.out.println(id_s);
        int id = Integer.parseInt(id_s);
        System.out.println(id);
        String bpID = request.getParameter("bpID");
        String facID = request.getParameter("facID");
        String memID = request.getParameter("memID");

        SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");

        Date startDate;
		try {
			startDate = new Date(fm.parse(request.getParameter("startDate")).getTime());
			Date endDate = new Date(fm.parse(request.getParameter("endDate")).getTime());
	        String contact = request.getParameter("contact");
	        String carNum = request.getParameter("carNum");
	        String status = request.getParameter("status");

	        Reservation rsv = new Reservation();
	        rsv.setBusinessPlaceID(bpID);
	        rsv.setFacilityID(facID);
	        rsv.setMemberID(memID);
	        rsv.setStartDate(startDate);
	        rsv.setEndDate(endDate);
	        rsv.setContact(contact);
	        rsv.setCarNumber(carNum);
	        rsv.setStatus(status);
	        rsv.setReservationID(id);

	        ReservationService service = ReservationService.getInstance();
	        service.ReservationUpdate(rsv);

	        request.setAttribute("id", id);
	        HttpUtil.forward(request, response, "/result/ReservationUpdateResult.jsp");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
}
