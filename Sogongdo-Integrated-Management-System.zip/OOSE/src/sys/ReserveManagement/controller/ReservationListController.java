package sys.ReserveManagement.controller;
import sys.Controller;
import sys.HttpUtil;
import sys.ReserveManagement.model.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class ReservationListController implements Controller
{
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ReservationService service = ReservationService.getInstance();
        ArrayList<Reservation> list = service.reservationList();
		String auth = (String)request.getSession().getAttribute("authority");
		if(auth !=null) {
			if(auth.equals("20") || auth.equals("30") || auth.equals("40") || auth.equals("50")) {
				request.setAttribute("list", list);
		        HttpUtil.forward(request, response, "/reservationListView.jsp");
			}
			else {
				HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
			}
		}else {
			HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
		}

        
    }

}
