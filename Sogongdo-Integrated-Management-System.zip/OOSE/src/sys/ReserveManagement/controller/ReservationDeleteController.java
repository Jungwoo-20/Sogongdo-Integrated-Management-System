package sys.ReserveManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.ReserveManagement.model.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ReservationDeleteController implements Controller
{
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        String id = request.getParameter("id");
        System.out.println(id);
        ReservationService service = ReservationService.getInstance();
        service.ReservationDelete(Integer.parseInt(id));

        HttpUtil.forward(request, response, "/result/ReservationDeleteResult.jsp");
    }
}
