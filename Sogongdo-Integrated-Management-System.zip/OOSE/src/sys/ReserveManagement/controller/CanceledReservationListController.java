package sys.ReserveManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.ReserveManagement.model.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class CanceledReservationListController implements Controller
{
    public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ReservationService service = ReservationService.getInstance();
        ArrayList<Reservation> list = service.canceledReservationList();

        request.setAttribute("list", list);
        HttpUtil.forward(request, response, "/canceledListView.jsp");
    }
}
