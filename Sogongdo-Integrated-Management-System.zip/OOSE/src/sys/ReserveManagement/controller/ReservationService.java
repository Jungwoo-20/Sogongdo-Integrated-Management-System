package sys.ReserveManagement.controller;

import sys.Controller;
import sys.HttpUtil;
import sys.ReserveManagement.model.*;

import java.util.ArrayList;

public class ReservationService {
    private static ReservationService service = new ReservationService();
    public ReservationDAO dao = ReservationDAO.getInstance();
    private ReservationService() {}
    public static ReservationService getInstance() {return service;}
    public void ReservationEnroll(Reservation rsv) {dao.enrollReservation(rsv);}
    public void ReservationUpdate(Reservation rsv) {dao.updateReservation(rsv);}
    public void ReservationDelete(int id) {dao.deleteReservation(id);}
    public ArrayList<Reservation> reservationList()
    {
        ArrayList<Reservation> list = dao.getReservationList();
        return list;
    }
    public ArrayList<Reservation> canceledReservationList()
    {
        ArrayList<Reservation> list = dao.getCanceledReservationList();
        return list;
    }
}
