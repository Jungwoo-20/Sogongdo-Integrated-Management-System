package sys.MemberManagement.model;

import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import sys.Dao;

public class MemberDAO {
	private static MemberDAO dao = new MemberDAO();
	private DataSource ds;
	Dao da = new Dao();

	public MemberDAO() {
	}

	public static MemberDAO getInstance() {
		return dao;
	}

	public boolean memberInsert(MemberDTO member) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		boolean flag = true;
		try {
			conn = da.connect();
			pstmt = conn.prepareStatement(
					"insert into oose.member(id,password,name,phoneNumber,authorityGrade) values(?,?,?,?,?)");
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPassword());
			pstmt.setString(3, member.getName());
			pstmt.setString(4, member.getPhoneNumber());
			pstmt.setString(5, member.getauthorityGrade());

			pstmt.executeUpdate();
		} catch (Exception ex) {
			System.out.println("DB insert 오류" + ex);
			flag = false;
		} finally {
			da.close(conn, pstmt);
		}
		return flag;
	}

	@SuppressWarnings("null")
	public String memberLogin(String id, String pwd) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String LoginId = null;
		PreparedStatement pstmt = null;
		try {
			conn = da.connect();
			pstmt = conn.prepareStatement("select * from oose.member where id =? and password =?");
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				LoginId = rs.getString("id");
				LoginId += "!";
				LoginId += rs.getString("authorityGrade");
			}
		} catch (Exception ex) {
			System.out.println("DB select 오류" + ex);
		} finally {
			da.close(conn, pstmt);
		}
		return LoginId;
	}

	public MemberDTO memberSearch(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		MemberDTO member = null;

		try {
			conn = da.connect();
			pstmt = conn.prepareStatement("Select * from oose.member where id=?");
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			String grade = null;
			if (rs.next()) {
				member = new MemberDTO();
				member.setId(rs.getString(1));
				member.setPassword(rs.getString(2));
				member.setName(rs.getString(3));
				member.setPhonNumber(rs.getString(4));
				if (rs.getString(5).equals("10")) {
					member.setauthorityGrade("회원");
				} else if (rs.getString(5).equals("20")) {
					member.setauthorityGrade("관리자");
				} else if (rs.getString(5).equals("30")) {
					member.setauthorityGrade("권한관리자");
				} else if (rs.getString(5).equals("40")) {
					member.setauthorityGrade("1관리자");
				} else if (rs.getString(5).equals("50")) {
					member.setauthorityGrade("2관리자");
				}
			}
		} catch (Exception ex) {
			System.out.println("select 오류 :" + ex);
		} finally {
			da.close(conn, pstmt, rs);
		}
		return member;
	}

	public boolean memberUpdate(MemberDTO member) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		boolean flag = true;
		try {
			conn = da.connect();
			pstmt = conn
					.prepareStatement("Update oose.member Set password = ?, name = ?, phoneNumber = ? where id = ?");
			pstmt.setString(1, member.getPassword());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getPhoneNumber());
			pstmt.setString(4, member.getId());

			pstmt.executeUpdate();
		} catch (Exception ex) {
			System.out.println("DB Update 오류" + ex);
			flag = false;
		} finally {
			da.close(conn, pstmt);
		}
		return flag;
	}

	public void memberDelete(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = da.connect();
			pstmt = conn.prepareStatement("Delete from oose.member where id = ?");
			pstmt.setString(1, id);

			pstmt.executeUpdate();
		} catch (Exception ex) {
			System.out.println("DB Delete 오류" + ex);
		} finally {
			da.close(conn, pstmt);
		}
	}
}
