package sys.MemberManagement.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import sys.Controller;
import sys.HttpUtil;

public class MemberLoginController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id = null;
		String passwd = null;
		id = request.getParameter("loginid");
		passwd = request.getParameter("loginpwd");

		// ��ȿ��üũ
		if (id.isEmpty() || passwd.isEmpty()) {
			request.setAttribute("error", "아이디 또는 비밀번호를 입력하지 않았습니다.");
			HttpUtil.forward(request, response, "/memberLogin.jsp");
			return;
		}
		MemberService service = MemberService.getInstance();
		String name = null;
		name = service.memberLogin(id, passwd);
		try {
			String[] tmp = name.split("!");
			if(name != null) {
				HttpSession session = request.getSession();
				session.setAttribute("id", id);
				session.setAttribute("pwd", passwd);
				session.setAttribute("authority", tmp[1]);
				System.out.println("회원 등급  : " + tmp[1]);
				request.setAttribute("loginId", id);
				
				HttpUtil.forward(request, response, "/result/memberLoginSuccess.jsp");
			}
			else {
				request.setAttribute("error", "회원 정보가 일치하지 않습니다.");
				HttpUtil.forward(request, response, "memberLogin.jsp");
			}
		}catch(Exception e){
			request.setAttribute("error", "회원 정보가 일치하지 않습니다.");
			HttpUtil.forward(request, response, "memberLogin.jsp");
		}
		

	}

}
