package sys.MemberManagement.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import sys.Controller;
import sys.HttpUtil;
import sys.MemberManagement.model.MemberDTO;


public class MemberInsertController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = null;
		String passwd = null;
		String name = null;
		String phone = null;
		id = request.getParameter("id");
		passwd = request.getParameter("pwd");
		name = request.getParameter("name");
		phone = request.getParameter("phone");

		
		if (id.isEmpty() || passwd.isEmpty() || name.isEmpty() || phone.isEmpty()) {
			request.setAttribute("error", "��� ������ �Է����� �ʾҽ��ϴ�.");
			HttpUtil.forward(request, response, "/memberInsert.jsp");
			return;
		}

		MemberDTO member = new MemberDTO();
		member.setId(id);
		member.setPassword(passwd);
		member.setName(name);
		member.setPhonNumber(phone);
		member.setauthorityGrade("10"); //ȸ������ ���

		MemberService service = MemberService.getInstance();
		boolean flag = service.memberInsert(member);
		if(flag == true) {
			request.setAttribute("id", id);
			HttpUtil.forward(request, response, "/result/memberInsertOutput.jsp");	
		}
		else {
			request.setAttribute("error", "ȸ�� ������ �ߺ��Դϴ�.");
			HttpUtil.forward(request, response, "memberInsert.jsp");
		}

	}

}
