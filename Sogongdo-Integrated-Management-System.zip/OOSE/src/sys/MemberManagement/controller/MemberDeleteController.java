package sys.MemberManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sys.Controller;
import sys.HttpUtil;

public class MemberDeleteController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		MemberService service = MemberService.getInstance();
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		System.out.println(id);
		if (session.getAttribute("id") == null) {
			request.setAttribute("error", "�α��εǾ� ���� �ʽ��ϴ�.");
			HttpUtil.forward(request, response, "/memberDelete.jsp");
			return;
		} 
		service.memberDelete(id);
		request.setAttribute("id", id);
		HttpUtil.forward(request, response, "/result/memberDeleteSuccess.jsp");
	}

}
