package sys.MemberManagement.controller;

import sys.MemberManagement.model.MemberDAO;
import sys.MemberManagement.model.MemberDTO;

public class MemberService {
	private static MemberService service = new MemberService();
	public MemberDAO dao = MemberDAO.getInstance();

	private MemberService() {

	}

	public static MemberService getInstance() {
		return service;
	}

	public boolean memberInsert(MemberDTO member) {
		return dao.memberInsert(member);
	}

	public String memberLogin(String id, String passwd) {
		return dao.memberLogin(id, passwd);
	}
	public MemberDTO memberSearch(String id){
		MemberDTO member = dao.memberSearch(id);
		return member;
	}
	public boolean memberUpdate(MemberDTO member) {
		return dao.memberUpdate(member);
	}
	public void memberDelete(String id) {
		dao.memberDelete(id);
	}


}
