package sys.MemberManagement.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import sys.Controller;

import java.util.*;


public class MemberFrontController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	String charset = null;
	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		charset = config.getInitParameter("charset");
		list = new HashMap<String, Controller>();
		list.put("/memberInsert.me",  new MemberInsertController());
		list.put("/memberlogin.me",  new MemberLoginController());
		list.put("/memberSearch.me",  new MemberSearchController());
		list.put("/memberUpdate.me",  new MemberUpdateController());
		list.put("/memberDelete.me",  new MemberDeleteController());
	}
	
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		request.setCharacterEncoding(charset);

		String url = request.getRequestURI();

		String contextPath = request.getContextPath();
		
		String path = url.substring(contextPath.length());
		
		Controller subController = list.get(path);
		subController.execute(request, response);
	}
	
	
	
}