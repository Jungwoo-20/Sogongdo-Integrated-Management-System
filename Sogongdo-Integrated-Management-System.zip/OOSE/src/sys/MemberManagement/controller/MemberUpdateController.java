package sys.MemberManagement.controller;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sys.Controller;
import sys.HttpUtil;
import sys.MemberManagement.model.MemberDTO;

public class MemberUpdateController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String passwd = null;
		String name = null;
		String phone = null;
		passwd = request.getParameter("pwd");
		name = request.getParameter("name");
		phone = request.getParameter("phone");


		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		if (session.getAttribute("id") == null) {
			request.setAttribute("info", null);
			request.setAttribute("error", "로그인 되어있지 않습니다.");
			HttpUtil.forward(request, response, "/memberUpdate.jsp");
			return;
		}
		if(session.getAttribute("id") != null) {
			try {
				// ��ȿ��üũ
				if (passwd.isEmpty() || name.isEmpty() || phone.isEmpty()) {
					request.setAttribute("error", "모든 항목을 입력하시오.");
					HttpUtil.forward(request, response, "/memberUpdate.jsp");
					return;
				}
			}catch(Exception e) {
				request.setAttribute("info", "tmp");
				HttpUtil.forward(request, response, "/memberUpdate.jsp");
				return;
			}
		}

		MemberDTO member = new MemberDTO();
		member.setId(id);
		member.setPassword(passwd);
		member.setName(name);
		member.setPhonNumber(phone);
		member.setauthorityGrade((String) session.getAttribute("authority"));

		MemberService service = MemberService.getInstance();
		boolean flag = service.memberUpdate(member);
		if(flag == true) {
			request.setAttribute("id", id);
			HttpUtil.forward(request, response, "/result/memberUpdateSuccess.jsp");	
		}
		else {
			request.setAttribute("error", "회원 정보 형식에 맞지 않습니다.");
			HttpUtil.forward(request, response, "memberUpdate.jsp");
		}

	}

}