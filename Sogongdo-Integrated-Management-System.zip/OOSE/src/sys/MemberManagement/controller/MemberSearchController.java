package sys.MemberManagement.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import sys.Controller;
import sys.HttpUtil;
import sys.MemberManagement.model.MemberDTO;


public class MemberSearchController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		MemberService service = MemberService.getInstance();
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		System.out.println(id);
		if (session.getAttribute("id") == null) {
			request.setAttribute("error", "�α��εǾ� ���� �ʽ��ϴ�.");
			HttpUtil.forward(request, response, "/memberSearch.jsp");
			return;
		} 
		MemberDTO member = service.memberSearch(id);
		request.setAttribute("member", member);
		HttpUtil.forward(request, response, "/result/memberSearchSuccess.jsp");
	}

}
