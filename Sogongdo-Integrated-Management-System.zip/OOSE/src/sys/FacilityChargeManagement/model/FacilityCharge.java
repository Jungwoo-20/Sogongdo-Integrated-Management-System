package sys.FacilityChargeManagement.model;

public class FacilityCharge {
	private String facilityChargeId;
	private String facilityId;
	private String buyerType;
	private int charge;
	
	public String getFacilityChargeId() {
		return facilityChargeId;
	}
	public void setFacilityChargeId(String facilityChargeId) {
		this.facilityChargeId = facilityChargeId;
	}
	public String getFacilityId() {
		return facilityId;
	}
	public void setFacilityId(String facilityId) {
		this.facilityId = facilityId;
	}
	public String getBuyerType() {
		return buyerType;
	}
	public void setBuyerType(String buyerType) {
		this.buyerType = buyerType;
	}
	public int getCharge() {
		return charge;
	}
	public void setCharge(int charge) {
		this.charge = charge;
	}


}
