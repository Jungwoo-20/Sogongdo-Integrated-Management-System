package sys.FacilityChargeManagement.model;



import java.sql.*;
import java.util.ArrayList;

import sys.Dao;

public class FacilityChargeDAO extends Dao{
	private static FacilityChargeDAO dao = new FacilityChargeDAO();
	
	private  FacilityChargeDAO() {}
	
	public static  FacilityChargeDAO getInstance() {
		return dao;
	}
	
		public void facilityChargeEnroll(FacilityCharge facilityCharge) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {		
				conn = connect();
				
				pstmt = conn.prepareStatement("select * from oose.facility where facilityName=?");
				pstmt.setString(1, facilityCharge.getFacilityId());
				String facilityId = "";
				
				rs = pstmt.executeQuery();
				while(rs.next()) {
					facilityId = rs.getString("facilityId");
				}
				pstmt.close();
				
				
				
				pstmt = conn.prepareStatement("insert into oose.facilityCharge values(?,?,?,?)");
				pstmt.setString(1,  facilityCharge.getFacilityChargeId());
				pstmt.setString(2, facilityId);
				pstmt.setString(3, facilityCharge.getBuyerType());
				pstmt.setInt(4, facilityCharge.getCharge());
				
				pstmt.executeUpdate();
			}catch(Exception ex) {
				System.out.println("DB insert ����" + ex);
			}finally {
				close(conn, pstmt);
			}
		}
		
		public ArrayList<FacilityCharge> getFacilityChargeList(){
			ArrayList<FacilityCharge> list = new ArrayList<FacilityCharge>();
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			FacilityCharge facilityCharge = null;
			
			try {
				conn = connect();
				pstmt = conn.prepareStatement("select * from oose.facilityCharge");
				rs = pstmt.executeQuery();
				while(rs.next()) {
					facilityCharge = new FacilityCharge();
					facilityCharge.setFacilityChargeId(rs.getString(1));
					facilityCharge.setFacilityId(rs.getString(2));
					facilityCharge.setBuyerType(rs.getString(3));
					facilityCharge.setCharge(rs.getInt(4));
					list.add(facilityCharge);
				}
			} catch (Exception ex) {
				System.out.println("���� �߻�" + ex);
			} finally {
				close(conn, pstmt, rs);
			}
			
			return list;
		}
		
		public void facilityChargeDelete(String facilityChargeId) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			
			try {
				conn = connect();
				pstmt = conn.prepareStatement("delete from oose.facilityCharge where facilityChargeid=?");
				pstmt.setString(1, facilityChargeId);
				pstmt.executeUpdate();
			}catch(Exception ex) {
				System.out.println("DB delete error" + ex);
			}finally {
				close(conn, pstmt);
			}
		}
		
		public void facilityChargeUpdate(FacilityCharge facilityCharge) {
			Connection conn = null;
			PreparedStatement pstmt = null;
			
			try {
				conn = connect();
				pstmt = conn.prepareStatement("Update oose.facilityCharge set buyerType=?, charge=? where facilityChargeid=?");
				pstmt.setString(1, facilityCharge.getBuyerType());
				pstmt.setInt(2, facilityCharge.getCharge());
				pstmt.setString(3, facilityCharge.getFacilityChargeId());
				
				pstmt.executeUpdate();
			}catch (Exception ex) {
				System.out.println("DB ������Ʈ ����" + ex);
			}finally {
				close(conn,pstmt);
			}
		}

}
