package sys.FacilityChargeManagement.controller;
import sys.Controller;
import sys.HttpUtil;
import sys.FacilityChargeManagement.model.*;
import java.util.ArrayList;


public class FacilityChargeService {
	private static FacilityChargeService service = new FacilityChargeService();
	public FacilityChargeDAO dao = FacilityChargeDAO.getInstance();
	
	private FacilityChargeService() {
		
	}
	
	public static FacilityChargeService getInstance() {
		return service;
	}
	
	public void FacilityChargeEnroll(FacilityCharge facilityCharge) {
		dao.facilityChargeEnroll(facilityCharge);
	}
	
	public void FacilityChargeUpdate(FacilityCharge facilityCharge) {
		dao.facilityChargeUpdate(facilityCharge);
	}
	
	public void FacilityChargeDelete(String facilityChargeId) {
		dao.facilityChargeDelete(facilityChargeId);
	}
	
	public ArrayList<FacilityCharge> facilityChargeList(){
		ArrayList<FacilityCharge> list = dao.getFacilityChargeList();
		return list;
	}

}
