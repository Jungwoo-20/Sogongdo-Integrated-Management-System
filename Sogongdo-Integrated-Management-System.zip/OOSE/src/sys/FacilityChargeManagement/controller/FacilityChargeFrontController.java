package sys.FacilityChargeManagement.controller;
import sys.Controller;
import sys.HttpUtil;
import sys.FacilityChargeManagement.model.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;


public class FacilityChargeFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String charset = null;
	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		charset = config.getInitParameter("charset");
		list = new HashMap<String, Controller>();
		list.put("/FacilityChargeEnroll.fc",  new FacilityChargeEnrollController());
		list.put("/FacilityChargeUpdate.fc",  new FacilityChargeUpdateController());
		list.put("/FacilityChargeDelete.fc",  new FacilityChargeDeleteController());
		list.put("/FacilityChargeList.fc" , new FacilityChargeListController());
	}
	
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		request.setCharacterEncoding(charset);

		String url = request.getRequestURI();
		
		String contextPath = request.getContextPath();
		
		String path = url.substring(contextPath.length());
				
		Controller subController = list.get(path);
		subController.execute(request, response);
		
	}

}
