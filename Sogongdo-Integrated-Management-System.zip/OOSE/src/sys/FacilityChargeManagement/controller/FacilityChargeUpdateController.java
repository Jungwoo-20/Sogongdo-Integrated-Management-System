package sys.FacilityChargeManagement.controller;
import sys.Controller;
import sys.HttpUtil;
import sys.FacilityChargeManagement.model.*;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FacilityChargeUpdateController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String facilityChargeId = request.getParameter("facilityChargeId");
		String facilityId = request.getParameter("facilityId");
		String buyerType = request.getParameter("buyerType");
		String charge = request.getParameter("charge");
		
		if(buyerType.isEmpty() || charge.isEmpty()) {
			request.setAttribute("error", "�ʼ� ���� ���Է�");
			HttpUtil.forward(request, response, "/FacilityChargeUpdate.jsp");
			return;
		}
		
		FacilityCharge facilityCharge = new FacilityCharge();
		facilityCharge.setFacilityChargeId(facilityChargeId);
		facilityCharge.setFacilityId(facilityId);
		facilityCharge.setBuyerType(buyerType);
		facilityCharge.setCharge(Integer.parseInt(charge));
		
		FacilityChargeService service = FacilityChargeService.getInstance();
		service.FacilityChargeUpdate(facilityCharge);
		
		request.setAttribute("facilityChargeId", facilityChargeId);
		request.setAttribute("facilityId", facilityId);
		HttpUtil.forward(request, response, "/result/FacilityChargeUpdateResult.jsp");
		
	}
	
	

}
