package sys.FacilityChargeManagement.controller;
import sys.Controller;
import sys.HttpUtil;
import sys.FacilityChargeManagement.model.*;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FacilityChargeListController implements Controller{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FacilityChargeService service = FacilityChargeService.getInstance();
		ArrayList<FacilityCharge> list = service.facilityChargeList();
		String auth = (String)request.getSession().getAttribute("authority");
		if(auth !=null) {
			if(auth.equals("20") || auth.equals("30") || auth.equals("40") || auth.equals("50")) {
				request.setAttribute("FacilityChargeList", list);
				HttpUtil.forward(request, response, "/FacilityChargeListView.jsp");
			}
			else {
				HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
			}
		}else {
			HttpUtil.forward(request, response, "/DisplayBusinessplaceViewResult.jsp");
		}

		
	}

}
