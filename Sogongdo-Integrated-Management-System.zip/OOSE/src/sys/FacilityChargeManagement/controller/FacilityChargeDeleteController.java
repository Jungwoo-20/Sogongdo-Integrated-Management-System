package sys.FacilityChargeManagement.controller;
import sys.Controller;
import sys.HttpUtil;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





public class FacilityChargeDeleteController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("FacilityChargeId");
		FacilityChargeService service = FacilityChargeService.getInstance();
		service.FacilityChargeDelete(id);
		
		HttpUtil.forward(request, response, "/result/FacilityChargeDeleteResult.jsp");
	}

}
