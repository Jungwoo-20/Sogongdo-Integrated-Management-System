package sys.ProductManagement.controller;

import java.util.ArrayList;

import sys.ProductManagement.model.Product;
import sys.ProductManagement.model.ProductDAO;
import sys.ProductManagement.model.ProductSalesVolume;



public class ProductService {
	private static ProductService service = new ProductService();
	public ProductDAO dao = ProductDAO.getInstance();
	private ProductService() {
		
	}
	
	public static ProductService getInstance() {
		return service;
	}
	
	public void ProductEnroll(Product product) {
		dao.productEnroll(product);
	}
	
	
	public void ProductUpdate(Product product) {
		dao.productUpdate(product);
	}
	
	public void ProductDelete(String id) {
		dao.productDelete(id);
	}
	public ArrayList<Product> productList() {
		ArrayList<Product> list = dao.getProductList();
		return list;
	}
	public ArrayList<ProductSalesVolume> productsalesList() {
		ArrayList<ProductSalesVolume> list = dao.getProductSalesVolume();
		return list;
	}
	
	public void ProductPurchase(ProductSalesVolume sv) {
		dao.purchaseProduct(sv);
	}
	

}
