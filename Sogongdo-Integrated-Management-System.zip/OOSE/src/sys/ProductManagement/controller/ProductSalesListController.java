package sys.ProductManagement.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;
import sys.ProductManagement.model.Product;
import sys.ProductManagement.model.ProductSalesVolume;

public class ProductSalesListController implements Controller{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		ProductService service = ProductService.getInstance();
		ArrayList<ProductSalesVolume> list = service.productsalesList();
		
		request.setAttribute("list", list);
		HttpUtil.forward(request, response, "/ProductSalesList.jsp");
	}

	
}
