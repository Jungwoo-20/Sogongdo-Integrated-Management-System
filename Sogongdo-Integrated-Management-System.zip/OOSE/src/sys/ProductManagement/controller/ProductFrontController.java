package sys.ProductManagement.controller;

import java.io.*;


import javax.servlet.*;
import javax.servlet.http.*;

import sys.Controller;

import java.util.*;


public class ProductFrontController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	String charset = null;
	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		charset = config.getInitParameter("charset");
		list = new HashMap<String, Controller>();
		list.put("/productEnroll.pro",  new ProductEnrollController());
		list.put("/productUpdate.pro",  new ProductUpdateController());
		list.put("/productDelete.pro",  new ProductDeleteController());
		list.put("/productList.pro" , new ProductListController());
		list.put("/productUpdateForm.pro" , new ProductUpdateFormController());
		list.put("/productSalesList.pro" , new ProductSalesListController());
		list.put("/productPurchase.pro" , new ProductPurchaseController());
		list.put("/productPurchaseForm.pro" , new ProductPurchaseFormController());
		
	}
	
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		request.setCharacterEncoding(charset);

		String url = request.getRequestURI();

		String contextPath = request.getContextPath();
		
		String path = url.substring(contextPath.length());
		
		Controller subController = list.get(path);
		subController.execute(request, response);
	}
	
	
	
}