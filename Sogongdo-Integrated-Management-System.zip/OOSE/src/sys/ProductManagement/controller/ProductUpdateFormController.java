package sys.ProductManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;
import sys.ProductManagement.model.Product;

public class ProductUpdateFormController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String id = request.getParameter("id");
		Product product = new Product();
		product.setProductid(Integer.parseInt(id));
		
		request.setAttribute("product",product);
		HttpUtil.forward(request, response, "/ProductUpdate.jsp");
	}

}
