package sys.ProductManagement.controller;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sys.Controller;
import sys.HttpUtil;
import sys.ProductManagement.model.Product;



public class ProductUpdateController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String id = request.getParameter("productid");
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String quantity = request.getParameter("quantity");
		
		HttpSession session = request.getSession();
		String memberid = (String) session.getAttribute("id");
		
		
		SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");

		Date date = null;
		
		try {
			
			if(id.isEmpty() || name.isEmpty() || price.isEmpty() || quantity.isEmpty() || memberid.isEmpty() || request.getParameter("date").isEmpty()) {
				Product product = new Product();
				product.setProductid(Integer.parseInt(id));
				
				request.setAttribute("product",product);
				request.setAttribute("error", "�ʼ� ���� ���Է�");
				HttpUtil.forward(request, response, "/ProductUpdate.jsp");
				return;
			}
			
			
			date = new Date(fm.parse(request.getParameter("date")).getTime());
			
			Product product = new Product();
			product.setProductid(Integer.parseInt(id));
			product.setProductName(name);
			product.setPrice(Integer.parseInt(price));
			product.setSaleperiod(date);
			product.setQuantity(Integer.parseInt(quantity));
			product.setMemberId(memberid);
			
			ProductService service = ProductService.getInstance();
			service.ProductUpdate(product);
			
			request.setAttribute("id",id);
			HttpUtil.forward(request, response, "/result/ProductUpdateResult.jsp");
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
