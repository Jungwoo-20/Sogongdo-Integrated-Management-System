package sys.ProductManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;
import sys.ProductManagement.model.Product;

public class ProductPurchaseFormController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String num = request.getParameter("num");
		String price = request.getParameter("price");
		
		Product product = new Product();
		product.setProductid(Integer.parseInt(id));
		product.setProductName(name);
		product.setQuantity(Integer.parseInt(num));
		product.setPrice(Integer.parseInt(price));
		
		request.setAttribute("togle", request.getAttribute("togle"));
		request.setAttribute("product",product);
		HttpUtil.forward(request, response, "/ProductPurchase.jsp");
	}

}
