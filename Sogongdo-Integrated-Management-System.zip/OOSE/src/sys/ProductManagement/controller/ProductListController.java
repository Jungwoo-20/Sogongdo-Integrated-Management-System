package sys.ProductManagement.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;
import sys.BusinessplaceManagement.model.BusinessplaceDTO;
import sys.ProductManagement.model.Product;


public class ProductListController implements Controller {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductService service = ProductService.getInstance();
		ArrayList<Product> list = service.productList();
		
		
		String togle = request.getParameter("togle");
		String auth = (String)request.getSession().getAttribute("authority");
		
		if(togle==null) {
			if(auth !=null) {
				if(auth.equals("20") || auth.equals("30") || auth.equals("40") || auth.equals("50")) {
					request.setAttribute("list", list);
					HttpUtil.forward(request, response, "/ProductListView.jsp");
				}
				else{
					request.setAttribute("list", list);
					HttpUtil.forward(request, response, "/ProductListMemberView.jsp");
				}
			}else {
				request.setAttribute("list", list);
				HttpUtil.forward(request, response, "/ProductListMemberView.jsp");
			}
		}else {
			request.setAttribute("list", list);
			HttpUtil.forward(request, response, "/ProductListMemberView.jsp");
		}
		
		
	}
}
