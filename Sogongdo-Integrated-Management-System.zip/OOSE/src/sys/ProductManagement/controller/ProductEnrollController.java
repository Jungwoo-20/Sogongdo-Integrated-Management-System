package sys.ProductManagement.controller;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import sys.Controller;
import sys.HttpUtil;
import sys.ProductManagement.model.Product;

public class ProductEnrollController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String quantity = request.getParameter("quantity");
		
		HttpSession session = request.getSession();
		String memberid = (String) session.getAttribute("id");
		
		
		SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");

		Date date = null;
		
		try {
			
			if(id.isEmpty() || name.isEmpty() || price.isEmpty() || quantity.isEmpty() || memberid.isEmpty() || request.getParameter("date").isEmpty()) {
				
				request.setAttribute("error", "필수 정보 미입력");
				HttpUtil.forward(request, response, "/ProductEnroll.jsp");
				return;
			}
			
			date = new Date(fm.parse(request.getParameter("date")).getTime());
			
			Product product = new Product();
			product.setProductid(Integer.parseInt(id));
			product.setProductName(name);
			product.setPrice(Integer.parseInt(price));
			product.setSaleperiod(date);
			product.setQuantity(Integer.parseInt(quantity));
			product.setMemberId(memberid);
			
			ProductService service = ProductService.getInstance();
			service.ProductEnroll(product);
			
			request.setAttribute("id",id);
			HttpUtil.forward(request, response, "/result/EnrollResult.jsp");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
