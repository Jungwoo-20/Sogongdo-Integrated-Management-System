package sys.ProductManagement.controller;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sys.Controller;
import sys.HttpUtil;
import sys.ProductManagement.model.Product;
import sys.ProductManagement.model.ProductSalesVolume;

public class ProductPurchaseController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("productid");
		String price = request.getParameter("productprice");
		String limit = request.getParameter("productquantity");
		String quantity = request.getParameter("quantity");
		String name = request.getParameter("name");
		
		HttpSession session = request.getSession();
		
		SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");

		Date date = new Date(System.currentTimeMillis());
		
		
		if(id.isEmpty() || price.isEmpty() || quantity.isEmpty()) {
			Product product = new Product();
			product.setProductid(Integer.parseInt(id));
			product.setProductName(name);
			product.setQuantity(Integer.parseInt(limit));
			product.setPrice(Integer.parseInt(price));
			
			
			request.setAttribute("product",product);
			request.setAttribute("error", "���� ������ �Է��ϼ���.");
			HttpUtil.forward(request, response, "/ProductPurchase.jsp");
			return;
		}
		
		if(Integer.parseInt(limit) < Integer.parseInt(quantity)) {
			Product product = new Product();
			product.setProductid(Integer.parseInt(id));
			product.setProductName(name);
			product.setQuantity(Integer.parseInt(limit));
			product.setPrice(Integer.parseInt(price));
			
			request.setAttribute("product",product);
			request.setAttribute("error", "���� ���� ���� �ʰ�");
			HttpUtil.forward(request, response, "/ProductPurchase.jsp");
			return;
		}
		
		
		ProductSalesVolume sv = new ProductSalesVolume();
		sv.setProductId(Integer.parseInt(id));
		sv.setDate(date);
		sv.setVolume(Integer.parseInt(quantity));
		sv.setPrice(Integer.parseInt(quantity) * Integer.parseInt(price));
		
		ProductService service = ProductService.getInstance();
		service.ProductPurchase(sv);
		
		request.setAttribute("price",sv.getPrice());
		request.setAttribute("volume",sv.getVolume());
		
		HttpUtil.forward(request, response, "/result/PurchaseResult.jsp");

		
	}

}
