package sys.ProductManagement.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.HttpUtil;


public class ProductDeleteController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		ProductService service = ProductService.getInstance();
		service.ProductDelete(id);
		
		HttpUtil.forward(request, response, "/result/ProductDeleteResult.jsp");
	}

}
