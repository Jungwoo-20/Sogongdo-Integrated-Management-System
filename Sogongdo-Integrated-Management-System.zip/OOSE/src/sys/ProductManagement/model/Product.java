package sys.ProductManagement.model;

import java.sql.Date;

public class Product {
	private int productid;
	private String productName;
	private int price;
	private int quantity;
	private Date saleperiod;
	private String memberId;
	
	
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getSaleperiod() {
		return saleperiod;
	}
	public void setSaleperiod(Date saleperiod) {
		this.saleperiod = saleperiod;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}


	
}