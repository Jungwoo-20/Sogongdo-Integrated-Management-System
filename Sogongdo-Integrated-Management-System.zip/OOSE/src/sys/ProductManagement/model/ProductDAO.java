package sys.ProductManagement.model;

import java.sql.*;
import java.util.ArrayList;

import sys.Dao;



public class ProductDAO extends Dao{
	private static ProductDAO dao = new ProductDAO();
	
	private ProductDAO() {

	}
	
	public static ProductDAO getInstance() {
		return dao;
	}
	
	public void productEnroll(Product product) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("insert into oose.product values(?,?,?,?,?,?)");
			pstmt.setInt(1, product.getProductid());
			pstmt.setString(2, product.getProductName());
			pstmt.setInt(3, product.getPrice());
			pstmt.setInt(4, product.getQuantity());
			pstmt.setDate(5, product.getSaleperiod());
			pstmt.setString(6, product.getMemberId());
			
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB insert ����" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public ArrayList<Product> getProductList() {

		ArrayList<Product> list = new ArrayList<Product>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		Product product = null;

		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from oose.product");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				product = new Product();
				product.setProductid(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setPrice(rs.getInt(3));
				product.setQuantity(rs.getInt(4));
				product.setSaleperiod(rs.getDate(5));
				product.setMemberId(rs.getString(6));
				list.add(product);
			}

		} catch (Exception ex) {
			System.out.println("���� �߻� : " + ex);
		} finally {
			close(conn, pstmt, rs);
		}

		return list;
	}
	public void productDelete(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("delete from oose.product where productid=?");
			pstmt.setInt(1, Integer.parseInt(id));;
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB delete error" + ex);
		}finally {
			close(conn, pstmt);
		}
	}
	
	public void productUpdate(Product product) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("Update oose.product set productname=?, price=?, quantity=?, saleperiod=?, memberid=? where productid=?");
			pstmt.setString(1, product.getProductName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setInt(3, product.getQuantity());
			pstmt.setDate(4, product.getSaleperiod());
			pstmt.setString(5, product.getMemberId());
			pstmt.setInt(6, product.getProductid());
			
			pstmt.executeUpdate();
		}catch (Exception ex) {
			System.out.println("DB ������Ʈ ����" + ex);
		}finally {
			close(conn,pstmt);
		}
	}
	
	public void purchaseProduct(ProductSalesVolume sv) {
		ArrayList<ProductSalesVolume> list = getProductSalesVolume();
		int last = list.size() +1;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = connect();
			pstmt = conn.prepareStatement("insert into oose.productsalesvolume values(?,?,?,?,?)");
			pstmt.setInt(1, last);
			pstmt.setInt(2, sv.getProductId());
			pstmt.setDate(3, sv.getDate());
			pstmt.setInt(4, sv.getVolume());
			pstmt.setInt(5, sv.getPrice());
			
			pstmt.executeUpdate();
		}catch(Exception ex) {
			System.out.println("DB insert ����" + ex);
		}finally {
			close(conn, pstmt);
		}
		
		conn = null;
		pstmt = null;
		int curr = 0;
		ArrayList<Product> list2 = getProductList();
		for(int i=0; i<list2.size(); i++) {
			if(list2.get(i).getProductid() == sv.getProductId()) {
				curr = list2.get(i).getQuantity();
			}
		}
		try {
			conn = connect();
			pstmt = conn.prepareStatement("Update oose.product set quantity=? where productid=?");
			pstmt.setInt(1, curr - sv.getVolume());
			pstmt.setInt(2, sv.getProductId());
			
			pstmt.executeUpdate();
		}catch (Exception ex) {
			System.out.println("DB ������Ʈ ����" + ex);
		}finally {
			close(conn,pstmt);
		}
		
	}
	
	public ArrayList<ProductSalesVolume> getProductSalesVolume() {

		ArrayList<ProductSalesVolume> list = new ArrayList<ProductSalesVolume>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		ProductSalesVolume sv = null;

		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from oose.productsalesvolume");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				sv = new ProductSalesVolume();
				sv.setSalesId(rs.getInt(1));
				sv.setProductId(rs.getInt(2));
				sv.setDate(rs.getDate(3));
				sv.setVolume(rs.getInt(4));
				sv.setPrice(rs.getInt(5));
				list.add(sv);
			}

		} catch (Exception ex) {
			System.out.println("���� �߻� : " + ex);
		} finally {
			close(conn, pstmt, rs);
		}

		return list;
	}
	
}
