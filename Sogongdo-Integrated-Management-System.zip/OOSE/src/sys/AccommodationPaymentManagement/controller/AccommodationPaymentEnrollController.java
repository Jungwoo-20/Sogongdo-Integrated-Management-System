package sys.AccommodationPaymentManagement.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.AccommodationPaymentManagement.model.AccommodationPaymentDTO;

public class AccommodationPaymentEnrollController implements Controller{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		onPost(request, response);
	}
	
	public void onGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dispatchURL = "EnrollAccommodationPaymentView.jsp";
		
		// Foward
		RequestDispatcher dispatcher = request.getRequestDispatcher(dispatchURL);
        dispatcher.forward(request, response);
	}
	
	
	public void onPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String reservationIDStr = request.getParameter("accommodationReservationID");
		String method = request.getParameter("accommodationPaymentMethod");
		String amountStr = request.getParameter("accommodationPaymentAmount");
		
		int reservationID = -1;
		int amount = -1;
		int result = -1;
		
		String dispatchURL = null;
		
		try {
			if(reservationIDStr != null && !reservationIDStr.isEmpty()) {
				reservationID = Integer.parseInt(reservationIDStr);
			}
			
			if(amountStr != null && !amountStr.isEmpty()) {
				amount = Integer.parseInt(amountStr);
			}
			
			AccommodationPaymentDTO dto = new AccommodationPaymentDTO(-1, reservationID, method, amount, false);
			
			result = AccommodationPaymentService.getInstance().accommodationPaymentEnroll(dto);									// �ʼ� �׸� �˻�, ���� �˻�, �ߺ� �˻� ���� �� enroll
			
			dispatchURL = "result/EnrollAccommodationPaymentResult.jsp";
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		if(result != 1) {
			String errorMsg = "�� �� ����";
			switch(result) {
			case 2:
				errorMsg = "�ܷ�Ű ����";
				break;
			case 11:
				errorMsg = "�ʼ� �׸� ����";
				break;
			case 12:
				errorMsg = "���� ����";
				break;
			case 13:
				errorMsg = "�ߺ� ����";
				break;
			}
			request.setAttribute("error", "���� �˻� ���� Ȥ�� ���� �߻� : " + errorMsg);
			dispatchURL = "/EnrollAccommodationPaymentView.jsp";
		}
		
		// Foward
		RequestDispatcher dispatcher = request.getRequestDispatcher(dispatchURL);
        dispatcher.forward(request, response);
	}

}
