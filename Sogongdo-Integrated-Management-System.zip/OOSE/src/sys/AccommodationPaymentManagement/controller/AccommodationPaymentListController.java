package sys.AccommodationPaymentManagement.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sys.Controller;
import sys.AccommodationPaymentManagement.model.AccommodationPaymentDTO;

public class AccommodationPaymentListController implements Controller {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String where = "isDelete" + " = 0";
		ArrayList<AccommodationPaymentDTO> accommodationPaymnentList = AccommodationPaymentService.getInstance().accommodationPaymentList(where);
		
		request.setAttribute("AccommodationPaymentList", accommodationPaymnentList);
		
		// Foward
		RequestDispatcher dispatcher = request.getRequestDispatcher("/DisplayAccommodationPaymentView.jsp");
        dispatcher.forward(request, response);
	}

}
