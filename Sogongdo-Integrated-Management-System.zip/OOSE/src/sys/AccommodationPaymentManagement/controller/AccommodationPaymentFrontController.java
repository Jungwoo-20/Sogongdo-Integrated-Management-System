package sys.AccommodationPaymentManagement.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sys.Controller;

public class AccommodationPaymentFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String charset = null;
//	HashMap<String, Controller> list = null;
	
	@Override
	public void init(ServletConfig config)throws ServletException{
		charset = config.getInitParameter("charset");
		if(charset == null) {
			charset = "EUC-KR";
		}
		
//		list = new HashMap<String, Controller>();
//		list.put("/EnrollAccommodationPayment.ap", new AccommodationPaymentEnrollController());
//		list.put("/UpdateAccommodationPayment.ap", new AccommodationPaymentUpdateController());
//		list.put("/DeleteAccommodationPayment.ap", new AccommodationPaymentDeleteController());
//		list.put("/DisplayAccommodationPayment.ap", new AccommodationPaymentListController());
	}
	
//	@Override
//	public void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
//		request.setCharacterEncoding(charset);
//
//		String url = request.getRequestURI();
//		
//		String contextPath = request.getContextPath();
//		
//		String path = url.substring(contextPath.length());
//				
//		Controller subController = list.get(path);
//		subController.execute(request, response);
//		
//	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding(charset);
		
		// ���� üũ
		if(!authorityCheck(req)) {
			// ��� �Ұ�
			req.setAttribute("error", "���� �̴�");
			String dispatchURL = "/result/ErrorPage.jsp";
			RequestDispatcher dispatcher = req.getRequestDispatcher(dispatchURL);
	        dispatcher.forward(req, resp);
			return;
		}
		
		String url = req.getRequestURI();
		String contextPath = req.getContextPath();
		String path = url.substring(contextPath.length());
		
		// ��ȸ�� �ٷ� ��ȸ, �������� ������ ������ �� POST �� ó���� �ٸ��� ������ ���� ������ �����ֱ⸸ ��.
		switch(path) {
			case "/DisplayAccommodationPayment.ap":
				new AccommodationPaymentListController().execute(req, resp);
				return;
			case "/EnrollAccommodationPayment.ap":
				new AccommodationPaymentEnrollController().onGet(req, resp);
				break;
			case "/UpdateAccommodationPayment.ap":
				new AccommodationPaymentUpdateController().onGet(req, resp);
				break;
			case "/DeleteAccommodationPayment.ap":
				new AccommodationPaymentDeleteController().onGet(req, resp);
				break;
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding(charset);
		
		// ���� üũ
		if(!authorityCheck(req)) {
			// ��� �Ұ�
			req.setAttribute("error", "���� �̴�");
			String dispatchURL = "/result/ErrorPage.jsp";
			RequestDispatcher dispatcher = req.getRequestDispatcher(dispatchURL);
	        dispatcher.forward(req, resp);
			return;
		}
		
		String url = req.getRequestURI();
		String contextPath = req.getContextPath();
		String path = url.substring(contextPath.length());
		
		// ��ο� �´� �޼ҵ� ����
		switch(path) {
			case "/DisplayAccommodationPayment.ap":
				new AccommodationPaymentListController().execute(req, resp);
				break;
			case "/EnrollAccommodationPayment.ap":
				new AccommodationPaymentEnrollController().onPost(req, resp);
				break;
			case "/UpdateAccommodationPayment.ap":
				new AccommodationPaymentUpdateController().onPost(req, resp);
				break;
			case "/DeleteAccommodationPayment.ap":
				new AccommodationPaymentDeleteController().onPost(req, resp);
				break;
		}
	}
	
	private boolean authorityCheck(HttpServletRequest req) {
		// ���ǿ��� ���� ���� ȹ��
		HttpSession session = req.getSession();
		String authorityStr = (String)session.getAttribute("authority");
		
		// ��ȸ���� ��� ���� �Ұ�!
		if(authorityStr == null) {
			return false;
		}
		
		try {
			int authority = Integer.parseInt(authorityStr);
			
			// ��ȯ�� ȸ��(10) ���� ũ�� ������. ��� ����
			if(authority > 10) {
				return true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		 
		
		return false;
	}
}
