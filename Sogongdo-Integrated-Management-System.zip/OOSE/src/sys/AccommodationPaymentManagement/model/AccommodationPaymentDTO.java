package sys.AccommodationPaymentManagement.model;

public class AccommodationPaymentDTO {
	private int accommodationPaymentID;				// ���� ���� ID
	private int accommodationReservationID;				// ���� ���� ID
	private String accommodationPaymentMethod;			// ���� ���� ���
	private int accommodationPaymentAmount;				// ���� ���� �ݾ�
	private boolean isDelete;							// ��������
	
	public AccommodationPaymentDTO(int accommodationPaymentID, int accommodationReservationID,
			String accommodationPaymentMethod, int accommodationPaymentAmount, boolean isDelete) {
		this.accommodationPaymentID = accommodationPaymentID;
		this.accommodationReservationID = accommodationReservationID;
		this.accommodationPaymentMethod = accommodationPaymentMethod;
		this.accommodationPaymentAmount = accommodationPaymentAmount;
		this.isDelete = isDelete;
	}
	public int getAccommodationPaymentID() {
		return accommodationPaymentID;
	}
	public void setAccommodationPaymentID(int accommodationPaymentID) {
		this.accommodationPaymentID = accommodationPaymentID;
	}
	public int getAccommodationReservationID() {
		return accommodationReservationID;
	}
	public void setAccommodationReservationID(int accommodationReservationID) {
		this.accommodationReservationID = accommodationReservationID;
	}
	public String getAccommodationPaymentMethod() {
		return accommodationPaymentMethod;
	}
	public void setAccommodationPaymentMethod(String accommodationPaymentMethod) {
		this.accommodationPaymentMethod = accommodationPaymentMethod;
	}
	public int getAccommodationPaymentAmount() {
		return accommodationPaymentAmount;
	}
	public void setAccommodationPaymentAmount(int accommodationPaymentAmount) {
		this.accommodationPaymentAmount = accommodationPaymentAmount;
	}
	public boolean isDelete() {
		return isDelete;
	}
	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}
}
