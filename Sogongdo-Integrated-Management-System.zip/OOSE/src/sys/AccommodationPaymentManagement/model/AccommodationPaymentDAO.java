package sys.AccommodationPaymentManagement.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;


import sys.Dao;


public class AccommodationPaymentDAO extends Dao{
	// �̱���
	private static AccommodationPaymentDAO _instance;
	
	
	public static AccommodationPaymentDAO getInstance() {
		if(_instance == null) {
			_instance = new AccommodationPaymentDAO();
		}
		return _instance;
	}
	
	public ArrayList<AccommodationPaymentDTO> select(final ArrayList<String> columns, final String where) {
		Connection connection = null;
		Statement st = null;
		ResultSet rs = null;
		String sql = null;
		ArrayList<AccommodationPaymentDTO> result = new ArrayList<AccommodationPaymentDTO>();
		
		try {
			// ������ ������ �� ����
			StringBuilder sb = new StringBuilder();
			for(String column : columns) {
				sb.append(column + ", ");
			}
			sb.delete(sb.length() - 2, sb.length() - 1);
			String columnsStr = sb.toString();
			
			// ���ǹ� ����
			String whereStr = "";
			if(where != null) {
				whereStr = " WHERE " + where;
			}
			
			// ������ �ϼ�
			sql = "SELECT " + columnsStr + " FROM " + "oose.accommodationpayment " + whereStr;
			
			connection = connect();
			
			try {
				st = connection.createStatement();
				rs = st.executeQuery(sql);
				while(rs.next()) {
					int id = rs.getInt("accommodationPaymentID");
					int reservationID = rs.getInt("accommodationReservationID");
					String paymentMethod = rs.getString("accommodationPaymentMethod");
					int paymentAmount = rs.getInt("accommodationPaymentAmount");
					boolean isDelete = rs.getBoolean("isDelete");
					
					AccommodationPaymentDTO dto = new AccommodationPaymentDTO(id, reservationID, paymentMethod, paymentAmount, isDelete);
					result.add(dto);
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			closeConnection(connection);
		}
		
		
		// �迭 �ȿ� ������ ��������� ��ȯ, �� �迭�̸� null ��ȯ
		return result.size() > 0 ? result : null;
	}
	
	
	public int enroll(final AccommodationPaymentDTO dto) {
		Connection connection = null;
		String sql = null;
		
		try {
			sql = "INSERT INTO " + "oose.accommodationpayment" + " VALUES (?,?,?,?,?)";
			
			connection = connect(); 
			
			PreparedStatement ps = connection.prepareStatement(sql);
			if(dto.getAccommodationPaymentID() <= 0) {
				// ID�� ���������(0 ����) null�� ����. �̷��� ID�� ��� ä DB�� �״�� ������, AutoIncrement�� ���� ID�� �ڵ�������.
				ps.setNull(1, Types.INTEGER);
			}
			else {
				ps.setInt(1, dto.getAccommodationPaymentID());
			}
			
			ps.setInt(2, dto.getAccommodationReservationID());
			ps.setString(3, dto.getAccommodationPaymentMethod());
			ps.setInt(4, dto.getAccommodationPaymentAmount());
			ps.setBoolean(5, false);							// isDelete�� 0���� ����.
			
			ps.executeUpdate();
			return 1;		//SUCCEED
		}
		catch (Exception e) {
			e.printStackTrace();
			return -1;		// UNKNOWN
		}
		finally {
			closeConnection(connection);
		}
	}
	
	// 2020-06-21 Delete�� ������ �ƴ� Update�� isDelete�� 1(true)�� ������.
	public int delete(final AccommodationPaymentDTO dto) {
		Connection connection = null;
		String sql = null;
		
		try {	
			sql = "UPDATE " + "oose.accommodationpayment" + " SET "
					+ "isDelete" + " = ?"
					+ " WHERE " + "accommodationPaymentID" + " = ?";
		
			connection = connect();
			
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setBoolean(1, true);
			ps.setInt(2, dto.getAccommodationPaymentID());
			
			ps.executeUpdate();
			
			return 1;		//SUCCEED
		}

		catch (Exception e) {
			e.printStackTrace();
			return -1;		// UNKNOWN
		}
		finally {
			closeConnection(connection);
		}
	}
	
	public int update(final AccommodationPaymentDTO dto) {
		Connection connection = null;
		String sql = null;
		
		try {	
			sql = "UPDATE " + "oose.accommodationpayment" + " SET "
						+ "accommodationReservationID" + " = ?, "
						+ "accommodationPaymentMethod" + " = ?, "
						+ "accommodationPaymentAmount" + " = ?, "
						+ "isDelete" + " = ?"
						+ " WHERE " + "accommodationPaymentID" + " = ?";
			
			connection = connect();
			
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setInt(1, dto.getAccommodationReservationID());
			ps.setString(2, dto.getAccommodationPaymentMethod());
			ps.setInt(3, dto.getAccommodationPaymentAmount());
			ps.setBoolean(4, dto.isDelete());
			ps.setInt(5, dto.getAccommodationPaymentID());
			
			ps.executeUpdate();
			return 1;		//SUCCEED
		}
		catch (Exception e) {
			e.printStackTrace();
			return -1;		// UNKNOWN
		}
		finally {
			closeConnection(connection);
		}
	}
	
	private void closeConnection(Connection connection) {
		if(connection != null) {
			try {
				connection.close();					
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}
	
}
